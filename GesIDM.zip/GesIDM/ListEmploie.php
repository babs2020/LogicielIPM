<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
    <?php 
    include("connexion.php");
    $sql="SELECT * FROM emploie";
    $stmt= $db->prepare($sql);
    $stmt->execute();
?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content static-tables-page">
                    <div class="title-block">
     <section class="section">
                        <div class="row" style="background-color: #412093">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                                                 
                                    <a href="ajoutDelibere.php"> <button type="button" class="btn btn-success btn-lg" >AJOUTER UN EMPLOIE</button></a>
                                                                 <center>     Liste des Emploie du temp par  classe </center>
                        </h3> </div>
                                        <section class="example">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                    <thead style="background-color: #509231; color: red;" >
                                                        <tr>
                                                            <th>#</th>
                                                        	<th>Classe</th>
                                                            <th>Filiere</th>
                                                            <th>Fiche d'emploie du temp</th>
                                                            <th>Date Enregistrement</th>
                                                            <th>Action</th>
                                                            <th>Telecharger</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                        <tr>
                                                            <td><?php echo $i; ?></td>
                                                            <td><?php echo $row['nom_classe']; ?></td>
                                                            <td><?php echo $row['filieres']; ?></td>
                                                            <td><a href="Emploie/<?php  echo $row['fiche_emploie']; ?>"><?php echo $row['fiche_emploie']; ?></a></td>
                                                            <td><?php echo $row['date_enreg']; ?></td>
                                                            <td><a href="FormModifEmploie.php?id_emploie=<?php echo $row['id_emploie']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-edit"></em></div></a>
                                                            	<a href="suppDelibere.php?IDDELI=<?php echo $row['IDDELI']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"></em></div></a></td>
                                                                <td>
                                                                <a target="_blank" href="Emploie/<?php  echo $row['fiche_emploie']; ?> "><div class="col-md-3 col-sm-4"><em class="fa fa-download"  aria-expanded="true" ></em></div></a></center> </td>
                                                        </tr>
                                                          <?php  
                                                               $i++;
                                                            }?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                </article>
</div>
</div>