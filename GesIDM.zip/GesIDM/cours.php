<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sideprof.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content buttons-page" style="background-color:orange;">
	 <div class="title-block">
	 	<h3 class="title">
						Formulaire d'ajout cours
					</h3> </div>
					 <?php 
                            include("connexion.php");
                            $sql="SELECT nom_classe FROM classe GROUP BY nom_classe";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                            //$row=$stmt->fetch();
                        ?>
                            <form role="form" action="EXE/add_cour.php" method="POST" enctype="MULTIPART/FORM-DATA">
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput">IDCOURS</label> <input type="text" class="form-control" id="formGroupExampleInput" name="idcour" disabled="disabled"> </fieldset>
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput2">Nom cours</label> <input type="text" class="form-control" id="formGroupExampleInput2" name="nom_cours" > </fieldset>
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Classe</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="classe">
                                	<option>Selectionner une classe</option>
                                	<?php while($row=$stmt->fetch()){ ?><option><?php echo $row['nom_classe']; }?></option>
                                </select> </fieldset>
                                <fieldset class="form-group">
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Filiere</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="filiere">
                                	<option>Selectionner une filiere</option>
                                						 <?php 
				                            include("connexion.php");
				                            $sql="SELECT filieres FROM classe GROUP BY filieres ";
				                            $fl= $db->prepare($sql);
				                            $fl->execute();
				                            //$row=$stmt->fetch();
				                        ?>
                                	<?php while($row=$fl->fetch()){ ?><option><?php echo $row['filieres']; }?></option>
                                </select> </fieldset>
                                <fieldset class="form-group">
                                <label class="control-label" for="formGroupExampleInput4">Fichier cours</label> <input type="file" class="form-control" name="cours" id="cours"> </fieldset>
                                    <fieldset
                                        class="form-group"> <label class="control-label" for="formGroupExampleInput7">Description</label> <textarea rows="3" class="form-control" id="formGroupExampleInput7" name="desc"></textarea> </fieldset>
                      
                                       <button type="submit" class="btn btn-oval btn-success">Enregistrer</button>
                                       <button type="submit" class="btn btn-oval btn-danger" style="margin-left: 700px;">Annuler</button> 
                            </form>
           </div>
       </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>
