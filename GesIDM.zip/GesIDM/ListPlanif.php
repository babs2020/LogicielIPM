<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
    <?php 
    include("connexion.php");
    $sql="SELECT * FROM planification";
    $stmt= $db->prepare($sql);
    $stmt->execute();
?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content static-tables-page">
                    <div class="title-block">
     <section class="section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                                                 
                                    <a href="ajoutDelibere.php"> <button type="button" class="btn btn-success btn-lg" >Ajouter une planification</button></a>
                                                                 <center>     Liste des plannifications du cours</center>
                        </h3> </div>
                                        <section class="example">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                        	<th>Classe</th>
                                                            <th>Filiere</th>
                                                            <th>Fiche de planiication</th>
                                                            <th>Date Enregistrement</th>
                                                            <th>Action</th>
                                                            <th>Telecharger</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                        <tr>
                                                            <td><?php echo $i; ?></td>
                                                            <td><?php echo $row['nom_classe']; ?></td>
                                                            <td><?php echo $row['filieres']; ?></td>
                                                            <td><a href="fichier_cour/<?php  echo $row['fichier_planif']; ?>"><?php echo $row['fichier_planif']; ?></a></td>
                                                            <td><?php echo $row['date_enreg']; ?></td>
                                                            <td><a href="ForModifDelibere.php?IDDELI=<?php echo $row['IDDELI']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-edit"></em></div></a>
                                                            	<a href="suppPlanif.php?id_planif=<?php echo $row['id_planif']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"></em></div></a></td>
                                                                <td>
                                                                <a target="_blank" href="fichier_cour/<?php  echo $row['supportDeli']; ?> "><div class="col-md-3 col-sm-4"><em class="fa fa-download"  aria-expanded="true" ></em></div></a></center> </td>
                                                        </tr>
                                                          <?php  
                                                               $i++;
                                                            }?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>