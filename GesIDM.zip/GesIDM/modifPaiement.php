<?php 
$mat=filter_input(INPUT_POST,'matricule');
if (isset($mat)) {
	include'connexion.php';
    $id= $_GET['id_paiement'];
	  $matricule= $_POST['matricule'];
    $cni=$_POST['cni'];
  $nom= $_POST['nomEt'];
  $prenom= $_POST['prenomEt'];
    $dateNaiss= $_POST['dateNaiss'];
    $lieuNaiss= $_POST['lieuNais'];
    $filiere=$_POST['filiere'];
    $classe= $_POST['classe'];
    $cout= $_POST['cout'];
    $motif=$_POST['motif'];
    $frais=$_POST['frais'];
    $novembre= $_POST['Novembre'];
    $decembre= $_POST['decembre'];
    $janvier= $_POST['janvier'];
    $fevrier= $_POST['fevrier'];
    $mars= $_POST['mars'];
    $avril= $_POST['avril'];
    $mai= $_POST['mai'];
    $juin= $_POST['juin'];
    $juillet= $_POST['juillet'];
    $aout= $_POST['aout'];
    $totaux=$frais+$novembre+$decembre+$janvier+$fevrier+$mars+$avril+$mai+$juin+$juillet+$aout;
    $creance=$cout-$totaux;
	    if(!empty($nomEt) || !empty($prenomEt) || !empty($cout) || !empty($frais) || !empty($dateNaiss) || !empty($lieuNaiss)  || !empty($novembre)  || !empty($decembre) || !empty($janvier) || !empty($classe) || !empty($filiere)  || !empty($fevrier) || !empty($mars) || !empty($avril))
	    {
                                        /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("UPDATE  paiement SET matricule=?, cni=?, nomEt=?,prenomEt=?,dateNaiss=?,lieuNaiss=?,filiere=?,classe=?,cout=?, motif=?, frais=?,novembre=?,decembre=?,janvier=?,fevrier=?,mars=?,avril=?,mai=?,juin=?,juillet=?,aout=?,totaux=?,creance=?,date_enrg=NOW() WHERE id_paiement=$id");
                                $q->execute([$matricule, $cni,$nom,$prenom, $dateNaiss, $lieuNaiss, $filiere, $classe, $cout, $motif, $frais, $novembre, $decembre,$janvier, $fevrier, $mars, $avril, $mai, $juin, $juillet, $aout, $totaux, $creance]);
                                	if($q){
                                		echo'<script>
                   alert("Modification effectue");
                   document.location.href="ListPaie.php";
                   </script>';die();
								header("location:ListEt.php");
       	
                  }
                            /*erreur champ vide*/
        }else{
             echo'<script>
                   alert("veuillez faire une modification");
                   document.location.href="FormEtudiant.php";
                   </script>';die();
}
}
 ?>
