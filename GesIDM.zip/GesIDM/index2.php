<?php 
session_start() ;
include 'connexion.php'; 
if (isset($_SESSION['professeur'])) {
include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sideprof.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content buttons-page" style="background-color: blue;">
	 <div class="title-block">
	 	 <section class="section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                                <?php 
                            include("connexion.php");
                            $sql="SELECT * FROM cours order by date_enrg  ";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                        ?>
                            Liste des cours enregistre 
                        </h3> </div>
                                        <section class="example">
                                            <table class="table table-inverse">
                                                <thead>
                                                    <tr>
                                                        <th>IDCOURS</th>
                                                        <th>Nom Cours</th>
                                                        <th>Nom Classe</th>
                                                        <th>Filieres</th>
                                                         <th>Supporrt</th>
                                                         <th>Description</th>
                                                         <th>Date Enregistrement</th>
                                                         <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                    <tr>
                                                        <th scope="row"><?php echo $row['IDCOURS'] ?></th>
                                                        <td><?php echo $row['nom_cour']; ?></td>
                                                        <td><?php echo $row['nom_classe']; ?></td>
                                                        <td><?php echo $row['filieres']; ?></td>
                                                        <td><?php echo $row['f_cours']; ?></td>
                                                        <td><?php echo $row['description']; ?></td>
                                                        <td><?php echo $row['date_enrg']; ?></td>
                                                         <td>
                                                                <a href="supp_cour.php?id_cour=<?php echo $row['id_cour']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"  aria-expanded="true" ></em></div></a>
                                                                <a target="_blank" href="fichier_cour/<?php  echo $row['f_cours']; ?> "><div class="col-md-3 col-sm-4"><em class="fa fa-download"  aria-expanded="true" ></em></div></a></center> </td>
                                                    </tr>
                                                   <?php } ?>
                                                </tbody>
                                            </table>
                                        </section>
                </div>

            </section>

           </div>
       </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>
<?php
}else{
    echo '<script type="text/javascript">
    document.location.href="index.php"
</script>';
} ?>