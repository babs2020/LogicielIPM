<?php
	include("connexion.php");
	
	$id = filter_input(INPUT_GET, "id_matiere", FILTER_SANITIZE_NUMBER_INT) ;
	
	$typemsg="";
	$message=""; 
	
	$resquet = "DELETE FROM  matiere WHERE id_matiere = $id " ;
			if($db->exec($resquet)){
					echo'<script>
                   alert("Matiere supprimee");
                   document.location.href="index1.php";
                   </script>';die();			
				}else{
					$message="deja supprime
					<br>";
					$style="warning";
					$titremsg="Erreur!";
			}

?>