<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidebar.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content buttons-page" style="background-color: blue;">
	 <div class="title-block">
    <section class="section" >
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card sameheight-item">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
							SERVICE Comptable
						</h3> </div>
                                        <section class="section" >
                                            <a href="FormsUser.php"><button  type="button" class="btn btn-primary btn-lg" style="height: 200px;">Voir les etudiants par classe</button> </a> 
                                         </section>
                                    </div>
                                </div>
                            </div>
                                    </div>
                                </div>
                            </div>
                        </div>
               </section>
           </div>
       </article>
</div>
</div>
