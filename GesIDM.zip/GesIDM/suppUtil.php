<?php
	include("connexion.php");
	
	$id = filter_input(INPUT_GET, "id", FILTER_SANITIZE_NUMBER_INT) ;
	
	$typemsg="";
	$message=""; 
	
	$resquet = "DELETE FROM  utilisateur WHERE id = $id " ;
			if($db->exec($resquet)){
					echo'<script>
                   alert("Voulez vous suprimer cet utilisateur");
                   alert("confirmer la suppression");
                   document.location.href="ListUtil.php";
                   </script>';die();

					
				}else{
					$message="Les donnees ont pas déja été supprimees
					<br>";
					$style="warning";
					$titremsg="Erreur!";
			}

?>