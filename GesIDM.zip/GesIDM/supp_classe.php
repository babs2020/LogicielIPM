<?php
echo '
<script type="text/javascript">
	
		</script>';

	include("connexion.php");
	
	$id = filter_input(INPUT_GET, "id_classe", FILTER_SANITIZE_NUMBER_INT) ;

	$resquet = "DELETE FROM  classe WHERE id_classe = $id " ;
	$db->exec($resquet);
     echo'<script>
                   if (confirm("Voulez vous bien supprimer la classe")) {
                     
                   document.location.href="index1.php ";
                   }else{
                     document.location.href="addclGinf.php";
                   }</script>';die();	

echo '<script type="text/javascript">
}else{
    document.location.href="index2.php";
}
</script>';
?>