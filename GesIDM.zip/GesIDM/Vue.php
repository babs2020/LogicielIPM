<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
         <?php include 'pages/sidepeda.php'; ?>
          <?php 
    include("connexion.php");
    $id= $_GET['id_classe'];
    $sql= $db->query("SELECT * FROM classe WHERE id_classe=$id");
    $sql->execute($id);
    $row=$sql->fetch();
?>

    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page" style="background-color: #762135">
                    <div class="title-block">
                        <h3 class="title">
	 <h1 style="background-color: blue; color: red;"> <center> <?php echo $row['nom_classe']." ".$row['filieres'] ; ?> </center> </h1>
	</h3></div>
            	<section class="section">
                <div class="row sameheight-container">
                    <div class="col-md-12 col-xl-12 col col-xs-12 col-sm-12">
                        <div class="card card-block sameheight-item">
                            <div class="title-block">
                                <h3 class="title">
						Formulaire d'ajout matiere
					</h3> </div>
                                    <form method="POST" action="EXE/add_Matiere.php">
                                        <div class="form-group">
                                         <select class="form-control form-control-lg" name="semestre">
												<option>Selectionner une semestre</option>
												<option>Semestre 1</option>
												<option>Semestre 2</option>
												<option>Semestre 3 </option>
												<option>Semestre 4 </option>
												<option>Semestre 6 </option> </select> </div>
                                        <div class="form-group"> <label class="control-label">Nom de la matiere</label> <input type="text" class="form-control boxed" name="nom_matiere"> </div>
                                        <div class="form-group"> <label class="control-label">Credit</label> <input type="number" class="form-control boxed" placeholder="" name="credit"> </div>
                                        <label class="control-label">Coeff</label> <input type="number" class="form-control boxed" placeholder="" name="coeff"> </div>
                                        <div class="form-group"> <label class="control-label">Unite d'enseinement</label> <input type="text" disabled="disabled" class="form-control boxed" placeholder="Disabled input text" name="unite"> </div>
                                        <div class="form-group"> <label class="control-label">Classe</label> <select class="form-control form-control-lg" name="classe">
												<option>Selectionner une classe</option>
												<option><?php echo $row['nom_classe']; ?></h1></option>
												 </select> </div>
												  <?php 
													    $sql="SELECT * FROM utilisateur WHERE type='professeur'";
													    $stmt= $db->prepare($sql);
													    $stmt->execute();
													    $row=$stmt->fetch();
													?>
                                        <div class="form-group"> <label class="control-label">Proffeseur</label><select class="form-control form-control-lg" name="professeur">
												<option>Selectionner professeur</option>
                                                <?php while ($row=$stmt->fetch()) { ?>
												<option>
                                                <?php echo $row['prenom']." ".$row['nom']; ?></option> <?php } ?>
												 </select>  </div>
												  <button type="submit" class="btn btn-oval btn-success">Enregistrer</button>
                                       <button type="Reset" class="btn btn-oval btn-danger" style="margin-left: 1300px;">Annuler</button> 
                                    </form>

                            </div>
                            </div>
                           
                           <br><br><br>

                         <div class="col-md-l2">
                                <div class="card sameheight-item" data-exclude="xs">
                                    <div class="card-header card-header-sm bordered">
                                        <div class="header-block">
                                            <h3 class="title">Liste des matieres du classe</h3> </div>
                                    </div>
                                   <?php 
									    include("connexion.php");
									     $id= $_GET['id_classe'];
                                           $lcm= $db->query("SELECT * FROM classe WHERE id_classe=$id");
                                           $lcm->execute();
                                        $lm=$lcm->fetch();
    									    $sql="SELECT * FROM matiere where nom_classe='".$lm['nom_classe']."'";
									       $stmt= $db->prepare($sql);
									         $stmt->execute();
									?>
									<section class="example">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                        	<th>Unite</th>
                                                        	<th>Semestre</th>
                                                            <th>Nom Matiere</th>
                                                            <th>Credit</th>
                                                            <th>Coeff</th>
                                                            <th>Classe</th>
                                                            <th>Proffesseur</th>
                                                          
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                        <tr>
                    
                                                            <td><?php echo $row['unite']; ?></td>
                                                            <td><?php echo $row['semestre']; ?></td>
                                                            <td><?php echo $row['nom_matiere']; ?></td>
                                                            <td><?php echo $row['credit']; ?></td>
                                                            <td><?php echo $row['coeff']; ?></td>
                                                            <td><?php echo $row['nom_classe']; ?></td>
                                                            <td><?php echo $row['professeur']; ?></td>
                                                            <td><a href="FormMatiere.php?id_matiere=<?php echo $row['id_matiere']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-edit"></em></div></a>
                                                            	<a href="suppMat.php?id_matiere=<?php echo $row['id_matiere']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"></em></div></a></td>
                                                        </tr>
                                                          <?php  
                                                               $i++;
                                                            }?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                         <section class="section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                                <?php 
                            include("connexion.php");
                             $id= $_GET['id_classe'];
                             $rc= $db->query("SELECT * FROM classe WHERE id_classe=$id");
                              $rc->execute();
                              $sc=$rc->fetch();
                            $sql="SELECT * FROM cours where nom_classe='".$sc['nom_classe']."' AND filieres='".$sc['filieres']."' ";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                        ?>
                            Liste des cours enregistre 
                        </h3> </div>
                                        <section class="example">
                                            <table class="table table-inverse">
                                                <thead>
                                                    <tr>
                                                        <th>IDCOURS</th>
                                                        <th>Nom Cours</th>
                                                        <th>Nom Classe</th>
                                                        <th>Filieres</th>
                                                         <th>Supporrt</th>
                                                         <th>Description</th>
                                                         <th>Date Enregistrement</th>
                                                         <th>Action</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                    <tr>
                                                        <th scope="row"><?php echo $row['IDCOURS'] ?></th>
                                                        <td><?php echo $row['nom_cour']; ?></td>
                                                        <td><?php echo $row['nom_classe']; ?></td>
                                                        <td><?php echo $row['filieres']; ?></td>
                                                        <td><?php echo $row['f_cours']; ?></td>
                                                        <td><?php echo $row['description']; ?></td>
                                                        <td><?php echo $row['date_enrg']; ?></td>
                                                         <td>
                                                                <a href="supp_cour.php?id_cour=<?php echo $row['id_cour']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"  aria-expanded="true" ></em></div></a>
                                                                <a target="_blank" href="fichier_cour/<?php  echo $row['f_cours']; ?> "><div class="col-md-3 col-sm-4"><em class="fa fa-download"  aria-expanded="true" ></em></div></a></center> </td>
                                                    </tr>
                                                   <?php } ?>
                                                </tbody>
                                            </table>
                                        </section>
                                    </div></div>
                        </div>
                    
                    </section>
                </div>

</article>
    </div>
</div>
<?php include 'pages/footer.php'; ?>