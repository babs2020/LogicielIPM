<?php 
$nom=filter_input(INPUT_POST,'nomEt');
if (isset($nom)) {
	include'connexion.php';
    $id= $_GET['id_et'];
	   $nomEt= $_POST['nomEt'];
  $prenomEt= $_POST['prenomEt'];
    $email= $_POST['email'];
    $pays= $_POST['pays'];
   $dateNaiss= $_POST['dateNaiss'];
   $lieuNaiss= $_POST['lieuNais'];
   $sexe= $_POST['sexe'];
   $filiere= $_POST['filiere'];
   $classe= $_POST['classe'];
   $TelPrt= $_POST['TelPrt'];
   $TelTut= $_POST['TelTut'];
   $CNI=$_POST['CNI'];
    $photo=$_FILES['photo']['name'];
    $chemin=$_FILES['photo']['tmp_name'];
     move_uploaded_file($chemin, "../img/$photo");
     $adresse= $_POST['adresse'];
     $telephone= $_POST['telephone'];
	    if(!empty($nomEt) || !empty($prenomEt) || !empty($email) || !empty($pays) || !empty($dateNaiss) || !empty($lieuNaiss)  || !empty($sexe)  || !empty($sexe) || !empty($filiere) || !empty($classe) || !empty($TelPrt)  || !empty($TelTut) || !empty($CNI) || !empty($photo))
	    {
                                        /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("UPDATE etudiant SET nomEt=?,prenomEt=?,dateNaiss=?,lieuNaiss=?,pays=?,adresse=?,email=?,telephone=?,filieres=?,classe=?,sexe=?,CNI=?,TelPrt=?,TelTut=?,photo=? WHERE id_et=$id");
                                $q->execute([$nomEt,$prenomEt, $dateNaiss, $lieuNaiss, $pays, $adresse, $email,$telephone,$filiere,$classe, $sexe, $CNI, $TelPrt, $TelTut, $photo]); 
                                	if($q){
                                		echo'<script>
                   alert("Modification effectue");
                   document.location.href="ListEt.php";
                   </script>';die();
								header("location:ListEt.php");
       	
                  }
                            /*erreur champ vide*/
        }else{
             echo'<script>
                   alert("veuillez faire une modification");
                   document.location.href="FormEtudiant.php";
                   </script>';die();
}
}
 ?>
