<?php 
include'pages/head.php';
?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
<script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
     <?php 
    include("connexion.php");
    $id= $_GET['id_emploie'];
    $sql="SELECT * FROM emploie WHERE id_emploie=$id";
    $stmt= $db->prepare($sql);
    $stmt->execute();
    $row=$stmt->fetch();
    

    $sql1="SELECT * FROM classe GROUP BY nom_classe";
    $stmt1= $db->prepare($sql1);
    $stmt1->execute();
    $row1=$stmt1->fetch();

?>

    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page">
                    <div class="title-block">
                        <h3 class="title">
	Modifier  la deliberaion de la classe <?php echo $row['nom_classe'] ; ?>
	</h3></div>
                   
                    <section class="section">
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card card-block sameheight-item">
                                     <form role="form" action="ModifEmploie.php?id_emploie=<?php echo $row['id_emploie'];?>" method="POST" enctype="MULTIPART/FORM-DATA">
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Classe</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="classe" >
                                    <option ><?php echo $row['nom_classe']; ?></option>
                                    <option>Selectionner une classe</option>
                                    <?php while($row1=$stmt1->fetch()){ ?>
                                    <option><?php echo $row1['nom_classe']; }?></option>
                                </select> </fieldset>
                                <fieldset class="form-group">
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Filiere</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="filiere">
                                    <option><?php echo $row['filieres']; ?></option>
                                                         <?php 
                                            include("connexion.php");
                                            $sql="SELECT filieres FROM classe GROUP BY filieres ";
                                            $fl= $db->prepare($sql);
                                            $fl->execute();
                                            //$row=$stmt->fetch();
                                        ?>
                                    <?php while($row=$fl->fetch()){ ?><option><?php echo $row['filieres']; }?></option>
                                </select> </fieldset>
                                <fieldset class="form-group">
                                <label class="control-label" for="formGroupExampleInput4">Fichier Emploie du temps</label> <input type="file" class="form-control" name="emploie"  value="<?php echo $row['fiche_emploie']; ?>"> <?php echo $row['fiche_emploie']; ?></fieldset>
                                       <button type="submit" class="btn btn-oval btn-success">Enregistrer</button>
                                       <button type="submit" class="btn btn-oval btn-danger" style="margin-left: 700px;">Annuler</button> 
                            </form>
                                </div>
                            </div>
            </div>
            </section>
            
            </article>
        </div>
    </div>
    <?php include 'pages/footer.php'; ?>
       