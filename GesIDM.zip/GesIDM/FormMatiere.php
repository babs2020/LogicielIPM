<?php 
include'pages/head.php';
?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
<script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidebar.php'; ?>
     <?php 
    include("connexion.php");
    $id= $_GET['id_matiere'];
    $sql="SELECT * FROM matiere WHERE id_matiere=$id";
    $stmt= $db->prepare($sql);
    $stmt->execute();
    $row=$stmt->fetch();
?>

    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page">
                    <div class="title-block">
                        <h3 class="title">
	Modifier  la matiere <?php echo $row['nom_matiere'] ; ?>
	</h3></div>
                   
                    <section class="section">
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card card-block sameheight-item">
                                    <form method="post" action="modifMat.php?id_matiere=<?php echo $row['id_matiere'];?>" enctype="MULTIPART/FORM-DATA">
                                         <div class="form-group">
                                         <select class="form-control form-control-lg" name="semestre" >
                                                <option value="<?php echo $row['semestre'] ?>"><?php echo $row['semestre'] ?></option>
                                                <option >Semestre 1</option>
                                                <option >Semestre 2</option>
                                                <option >Semestre 3 </option>
                                                <option >Semestre 4 </option>
                                                <option >Semestre 6 </option> </select> </div>
                                        <div class="form-group"> <label class="control-label">Nom de la matiere</label> <input type="text" class="form-control boxed" name="nom_matiere" value="<?php echo $row['nom_matiere'] ?>"> </div>
                                        <div class="form-group"> <label class="control-label">Credit</label> <input type="number" class="form-control boxed" placeholder="" name="credit" value="<?php echo $row['credit'] ?>"> </div>
                                        <label class="control-label">Coeff</label> <input type="number" class="form-control boxed" placeholder="" name="coeff" value="<?php echo $row['coeff'] ?>" > </div>
                                        <div class="form-group"> <label class="control-label">Classe</label> <select class="form-control form-control-lg" name="classe" value >
                                                <option value="<?php echo $row['nom_classe'] ?>"><?php echo $row['nom_classe'] ?></option>
                                                <option ><?php echo $row['nom_classe']; ?></option>
                                                 </select> </div>
                                                  <?php 
                                                        $sql="SELECT * FROM utilisateur WHERE type='professeurs'";
                                                        $stmt= $db->prepare($sql);
                                                        $stmt->execute();
                                                        $row=$stmt->fetch();
                                                    ?>
                                        <div class="form-group"> <label class="control-label">Professeur</label><select class="form-control form-control-lg" name="professeur">
                                                <option value="<?php echo $row['prenom']." ".$row['nom']; ?>"><?php echo $row['prenom']." ".$row['nom']; ?></option>
                                                <option><?php echo $row['prenom']." ".$row['nom']; ?></option>
                                                 </select>  </div>
                                                 <br><br><br>
                                                  <button type="submit" class="btn btn-oval btn-success">Modifier</button>
                                       <button type="submit" class="btn btn-oval btn-danger" style="margin-left: 200px;">Annuler</button> 
                                    </form>
                                </div>
                            </div>
            </div>
            </section>
            
            </article>
        </div>
    </div>
       