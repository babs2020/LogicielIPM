<?php 
$nom=filter_input(INPUT_POST,'nom');
if (isset($nom)) {
	include'connexion.php';
    $id= $_GET['id'];
	$nom= $_POST['nom'];
	$prenom= $_POST['prenom'];
    $email= $_POST['email'];
    $password=$_POST['password'];
    $type= $_POST['type'];
    $adresse= $_POST['adresse'];
    $telephone= $_POST['telephone'];
    $photo=$_FILES['photo']['name'];
    $chemin=$_FILES['photo']['tmp_name'];
    move_uploaded_file($chemin, "img/$photo");
	    if(!empty($nom) || !empty($prenom) || !empty($email) || !empty($password) || !empty($type) || !empty($photo))
	    {
                                        /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("UPDATE utilisateur SET nom=?,prenom=?,email=?,password=?,type=?,photo=?,adresse=?,telephone=? WHERE id=$id");
                                $q->execute([$nom,$prenom,$email, $password, $type,$photo,$adresse,$telephone]); 
                                	if($q){
                                		echo'<script>
                   alert("Modification effectue");
                   document.location.href="ListUtil.php";
                   </script>';die();
								header("location:ListUtil.php");
       	
                  }
                            /*erreur champ vide*/
        }else{
             echo'<script>
                   alert("veuillez faire une modification");
                   document.location.href="FormModif.php";
                   </script>';die();
}
}
 ?>
