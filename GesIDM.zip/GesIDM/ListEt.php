<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sideAdmin.php'; ?>
    <?php 
    include("connexion.php");
    $sql="SELECT * FROM etudiant";
    $stmt= $db->prepare($sql);
    $stmt->execute();
?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content static-tables-page">
                    <div class="title-block">
                         <a href="AjoutEt.php"> <button type="button" class="btn btn-success btn-lg">Ajouter un nouveau Etudiant</button></a>
     <section class="section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                           <center> Liste des Etudiants</center>
                        </h3> </div>
                                        <section class="example">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                        	<th>Photo</th>
                                                            <th>Matricule</th>
                                                            <th>Nom</th>
                                                            <th>Prenom</th>
                                                            <th>Date Naissance</th>
                                                            <th>Lieu de Naissance</th>
                                                            <th>Pays</th>
                                                            <th>Adresse</th>
                                                            <th>Email</th>
                                                            <th>Telephone</th>
                                                            <th>Filiere</th>
                                                            <th>Classe</th>
                                                            <th>Sexe</th>
                                                            <th>CNI</th>
                                                            <th>Telephone Parent</th>
                                                            <th>Telephone Tuteur</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                        <tr>
                                                            <td><img src="img/<?php echo $row['photo']; ?>" width="60" height="60"/></td>
                                                            <td><?php echo $row['matricule'];?></td>
                                                            <td><?php echo $row['nomEt'];?></td>
                                                            <td><?php echo $row['prenomEt'];?></td>
                                                            <td><?php echo $row['dateNaiss'];?></td>
                                                            <td><?php echo $row['lieuNaiss']; ?></td>
                                                            <td><?php echo $row['pays']; ?></td>
                                                            <td><?php echo $row['adresse']; ?></td>
                                                            <td><?php echo $row['email']; ?></td>
                                                            <td><?php echo $row['telephone']; ?></td>
                                                            <td><?php echo $row['filieres'];?></td>
                                                            <td><?php echo $row['classe']; ?></td>
                                                            <td><?php echo $row['sexe'];?></td>
                                                            <td><?php echo $row['CNI'];?></td>
                                                            <td><?php echo $row['TelPrt'];?></td>
                                                            <td><?php echo $row['TelTut'];?></td>
                                                            <td><a href="FormEtudiant.php?id_et=<?php echo $row['id_et']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-edit"></em></div></a>
                                                            	<a href="suppEt.php?id_etudiant=<?php echo $row['id_etudiant']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"></em></div></a></td>
                                                        </tr>
                                                          <?php  
                                                               $i++;
                                                            }?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>