<?php
session_start() ;
include 'connexion.php'; 
if (isset($_SESSION['email'])) {
?>
<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidebar.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <?php include 'pages/contain.php'; ?>
</div>
</div>
<?php
}else{
	echo '<script type="text/javascript">
    document.location.href="index.php"
</script>';
} ?>