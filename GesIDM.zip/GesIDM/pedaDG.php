<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidebar.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content buttons-page" style="background-color: blue;">
	 <div class="title-block">
    <section class="section" >
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card sameheight-item">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
							LES FILIERES
						</h3> </div>
                                        <section class="section" >
                                            <a href="VueInfo.php"><button  type="button" class="btn btn-primary btn-lg" style="height: 200px; width: 400px;">Genie Informatique</button> </a> <a href="VueCivil.php"><button type="button" class="btn btn-secondary btn-lg" style="height: 200px; margin-left: 10; width: 400px;">Genie civil </button><a href="VueElec.php"><button type="button" class="btn btn-success btn-lg" style="height: 200px;margin-left: 10; width: 400px;">Genie Electro-Mecanique</button>                                    
                                            </section>
                                            <?php 
                                                    include("connexion.php");
                                                    $sql="SELECT * FROM delibere";
                                                    $stmt= $db->prepare($sql);
                                                    $stmt->execute();
                                                ?>
                                                 <section class="section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                                                                 <center>     Liste des Deliberations </center>
                        </h3> </div>
                                        <section class="example">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>#</th>
                                                            <th>Classe</th>
                                                            <th>Filiere</th>
                                                            <th>Fiche de Deliberation</th>
                                                            <th>Date Enregistrement</th>
        
                                                            <th>Telecharger</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                        <tr>
                                                            <td><?php echo $i; ?></td>
                                                            <td><?php echo $row['nom_classe']; ?></td>
                                                            <td><?php echo $row['filieres']; ?></td>
                                                            <td><a href="fichier_cour/<?php  echo $row['supportDeli']; ?>"><?php echo $row['supportDeli']; ?></a></td>
                                                            <td><?php echo $row['date_enreg']; ?></td>
                                                            
                                                                <td>
                                                                <a target="_blank" href="fichier_cour/<?php  echo $row['supportDeli']; ?> "><div class="col-md-3 col-sm-4"><em class="fa fa-download"  aria-expanded="true" ></em></div></a></center> </td>
                                                        </tr>
                                                          <?php  
                                                               $i++;
                                                            }?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
               </section>

           </div>
       </article>
</div>
</div>