<?php 
include'pages/head.php';
?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
<script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
     <?php 
    include("connexion.php");
    $id= $_GET['id'];
    $sql="SELECT * FROM utilisateur WHERE id=$id";
    $stmt= $db->prepare($sql);
    $stmt->execute();
    $row=$stmt->fetch();
?>

    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page">
                    <div class="title-block">
                        <h3 class="title">
	Modifier  L'utilisateur <?php echo $row['nom'] ; ?>
	</h3></div>
                   
                    <section class="section">
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card card-block sameheight-item">
                                    <form method="post" action="modifUtil.php?id=<?php echo $row['id']; ?>" enctype="MULTIPART/FORM-DATA">
                                         <div class="form-group"> <label class="control-label">Nom Utilisateur</label> <input type="text" class="form-control boxed" placeholder="Nom..." name="nom" value="<?php echo $row['nom'] ?>"> </div>
                                         <div class="form-group"> <label class="control-label">Prenom utilisateur</label> <input type="text" class="form-control boxed" placeholder="Prenom..." name="prenom" value="<?php echo $row['prenom'] ?>"> </div>
                                        <div class="form-group"> <label class="control-label">Email</label> <input type="email" class="form-control boxed" name="email" value="<?php echo $row['email'] ?>"> </div>
                                        <div class="form-group"> <label class="control-label">Mot de pass</label> <input type="password" class="form-control boxed" name="password" value="<?php echo $row['password'] ?>"> </div>
                                        <div class="form-group"> <label class="control-label">Type utilisateur</label> <input type="text" class="form-control boxed" placeholder="type..." name="type" value="<?php echo $row['type'] ?>"> </div>
                                        <div class="form-group"> <label class="control-label">adresse utilisateur</label> <input type="text" class="form-control boxed" placeholder="type..." name="adresse" value="<?php echo $row['adresse'] ?>"> </div>
                                        <div class="form-group"> <label class="control-label">Telephone utilisateur</label> <input type="text" class="form-control boxed" placeholder="type..." name="telephone" value="<?php echo $row['telephone'] ?>"> </div>
                                        <div class="form-group"> <label class="control-label">Photo</label> <input type="file" class="form-control boxed" placeholder="type..." name="photo" id="photos" value="<?php echo $row['photo'] ?>"> </div>
                                       <button type="submit" class="btn btn-oval btn-success">Enregistrer</button>
                                       <button type="submit" class="btn btn-oval btn-danger" style="margin-left: 700px;">Annuler</button> 
                                    </form>
                                </div>
                            </div>
            </div>
            </section>
            
            </article>
        </div>
    </div>v