<?php
session_start() ;
include 'connexion.php'; 
if (isset($_SESSION['pedagogue'])) {
?>
<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content buttons-page" style="background-color: #902145;">
	 <div class="title-block">
    <section class="section" style="background-color: #562955;">
        <div class="header-block header-block-search hidden-sm-down">
                        <form role="search" method="GET" action="ReClasse.php">
                            <div class="input-container">  
                             <input type="search" placeholder="Rechercher par nom classe" style="background-color:orange ; width: 250px; height: 50px;" name="R">
                            <input type="submit"    class="fa fa-search" value="Rechercher" > 
                                <div class="underline"></div>
                            </div>
                        </form>
                    </div>
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                                <?php 
                            include("connexion.php");
                            $sql="SELECT * FROM classe ";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                        ?>
                            Liste des classe de l'institut
                        </h3> </div>
                                        <section class="example">
                                            <table class="table table-hover">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Nom de la classe</th>
                                                        <th>Filiere</th>
                                        
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                    <tr>
                                                        <th scope="row"><?php echo $i++; ?></th>
                                                        <td><?php echo $row['nom_classe']; ?></td>
                                                        <td><?php echo $row['filieres']; ?></td>
                                                    </tr>
                                                   <?php } ?>
                                                </tbody>
                                            </table>
                                        </section>
                </div>

            </section>

           </div>
       </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>
<?php
}else{
    echo '<script type="text/javascript">
    document.location.href="index.php"
</script>';
} ?>