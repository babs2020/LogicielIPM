<?php 
            $nom=filter_input(INPUT_POST,'nom_matiere');
            if (isset($nom)) {
                include'connexion.php';
                $id=$_GET['id_matiere'];
                $nom_matiere= $_POST['nom_matiere'];
                $semestre= $_POST['semestre'];
                $coeff=$_POST['coeff'];
                $credit=$_POST['credit'];
                $nom_classe=$_POST['classe'];
                $professeur=$_POST['professeur'];
                    if(!empty($nom_matiere) || !empty($credit) || !empty($semestre) || !empty($coeff) || !empty($nom_classe) || !empty($professeur) )
                    {
                                                    /*  incscription de l'utilisateur  */  
                                            $q= $db->prepare("UPDATE matiere SET semestre=?, nom_matiere=?,credit=?,coeff=? , nom_classe=?,professeur=? WHERE id_matiere=$id");
                                            $q->execute([$semestre,$nom_matiere,$credit,$coeff,$nom_classe,$professeur]); 
                                                if($q){
                                                    echo'<script>
                               alert("Modification effectue");
                               document.location.href="index1.php";
                               </script>';die();
                                            header("location:Vue.php");
                    
                              }
                                        /*erreur champ vide*/
                    }else{
                         echo'<script>
                               alert("veuillez faire une modification");
                               document.location.href="FormModif.php";
                               </script>';die();
            }
            }
 ?>
