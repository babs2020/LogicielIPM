<?php
	include("connexion.php");
	
	$id = filter_input(INPUT_GET, "id_planif", FILTER_SANITIZE_NUMBER_INT) ;
	
	$typemsg="";
	$message=""; 
	
	$resquet = "DELETE FROM  planification WHERE id_planif = $id " ;
			if($db->exec($resquet)){
					echo'<script>
                   alert("fichier Planification   supprime");
                   document.location.href="ListPlanif.php";
                   </script>';die();			
				}else{
					$message="deja supprime
					<br>";
					$style="warning";
					$titremsg="Erreur!";
			}

?>