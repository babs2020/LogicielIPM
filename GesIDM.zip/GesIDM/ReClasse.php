	<meta charset="utf-8" />
	<?php
	 
	$bdd = new PDO('mysql:host=127.0.0.1;dbname=idm;charset=utf8','root','');
	 
	$articles = $bdd->query('SELECT nom_classe FROM classe ORDER BY id_classe DESC');
	if(isset($_GET['R']) AND !empty($_GET['R'])) {
	   $q = htmlspecialchars($_GET['R']);
	   $articles = $bdd->query('SELECT nom_classe FROM classe WHERE nom_classe LIKE "%'.$q.'%" ORDER BY id_classe DESC');
	   if($articles->rowCount() == 0) {
	      $articles = $bdd->query('SELECT nom_classe FROM classe WHERE CONCAT(nom_classe, contenu) LIKE "%'.$q.'%" ORDER BY id DESC');
	   }
	}
	?>
	<?php if($articles->rowCount() > 0) { ?>
	   <ul>
	   <?php while($a = $articles->fetch()) { ?>
	      <li><?= $a['nom_classe'] ?></li>
	   <?php } ?>
	   </ul>
	<?php } else { ?>y
	Aucun résultat pour: <?= $q ?>...
	<?php } ?>
