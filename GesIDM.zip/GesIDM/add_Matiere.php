<?php 
 include'connexion.php';
    $nom_matiere= $_POST['nom_matiere'];
    $semestre= $_POST['semestre'];
    $coeff= $_POST['coeff'];
    $credit= $_POST['credit'];
    $classe=$_POST['classe'];
     $professeur=$_POST['professeur'];
      $nom=filter_input(INPUT_POST,'nom_matiere');
   $unite=$classe."-".$semestre;
        if(isset($_POST['nom_matiere']) || isset($_POST['classe']))
                {

                    $req= $db->prepare('SELECT nom_matiere, nom_classe from matiere where nom_matiere=? and nom_classe=?');
                    $req->execute([$nom_matiere,$classe]);
                    $cl=$req->fetch();
                    if($cl){
                    echo'<script>
                   alert("Cet matiere est deja enregistre");
                   document.location.href="Vue.php";
                   </script>';die();

                            }else{
                                $q= $db->prepare("INSERT INTO matiere SET semestre=?,nom_matiere=?,credit=?,coeff=?,unite=?,nom_classe=?,professeur=?");
                                $q->execute([$semestre,$nom_matiere,$credit,$coeff,$unite,$classe,$professeur]);
                                echo'<script>
                   alert("Matiere enregistre");
                   document.location.href="index1.php";
                   </script>';die();
                           }
                      }  
 ?>
