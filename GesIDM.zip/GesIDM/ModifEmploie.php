

<?php 
            $nom=filter_input(INPUT_POST,'classe');
            if (isset($nom)) {
                include'connexion.php';
                $id=$_GET['id_emploie'];
                $filiere= $_POST['filiere'];
                $nom_classe=$_POST['classe'];
                 $Emploie=$_FILES['emploie']['name'];
                $chemin=$_FILES['emploie']['tmp_name'];
                move_uploaded_file($chemin, "Emploie/$Emploie");
                    if(!empty($filiere) ||  !empty($nom_classe) || !empty($Emploie) )
                    {
                                                    /*  incscription de l'utilisateur  */  
                             $q= $db->prepare("UPDATE emploie SET nom_classe=?, filieres=?,fiche_emploie=?,date_enreg=NOW() WHERE id_emploie=$id");
                              $q->execute([$nom_classe,$filiere,$Emploie]); 
                                      if($q){
                                          echo'<script>
                     alert("Modification effectue");
                     document.location.href="ListEmploie.php";
                     </script>';die();
                                  
          
                    }
                                        /*erreur champ vide*/
                    }else{
                         echo'<script>
                               alert("veuillez faire une modification");
                               document.location.href="FormModifEmploie.php";
                               </script>';die();
            }
 }
 ?>
