<?php 
            $nom=filter_input(INPUT_POST,'classe');
            if (isset($nom)) {
                include'connexion.php';
                $id=$_GET['id_releve'];
                $filiere= $_POST['filiere'];
                $nom_classe=$_POST['classe'];
                 $releve=$_FILES['releve']['name'];
                $chemin=$_FILES['releve']['tmp_name'];
                move_uploaded_file($chemin, "releves/$releve");
                    if(!empty($filiere) ||  !empty($nom_classe) || !empty($releve) )
                    {
                                                    /*  incscription de l'utilisateur  */  
                             $q= $db->prepare("UPDATE releve SET nom_classe=?, filieres=?,releve=?,date_enreg=NOW() WHERE id_releve=$id");
                              $q->execute([$nom_classe,$filiere,$releve]); 
                                      if($q){
                                          echo'<script>
                     alert("Modification effectue");
                     document.location.href="ListReleve.php";
                     </script>';die();
                                  
          
                    }
                                        /*erreur champ vide*/
                    }else{
                         echo'<script>
                               alert("veuillez faire une modification");
                               document.location.href="FormModifReleve.php";
                               </script>';die();
            }
 }
 ?>
