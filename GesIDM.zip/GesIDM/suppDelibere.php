<?php
echo '
<script type="text/javascript">
	
		</script>';

	include("connexion.php");
	
	$id = filter_input(INPUT_GET, "IDDELI", FILTER_SANITIZE_NUMBER_INT) ;

	$resquet = "DELETE FROM  delibere WHERE IDDELI = $id " ;
	$db->exec($resquet);
     echo'<script>
                   if (confirm("Voulez vous bien supprimer la classe")) {
                     
                   document.location.href="ListDelibere.php ";
                   }else{
                     document.location.href="addclGinf.php";
                   }</script>';die();	

echo '<script type="text/javascript">
}else{
    document.location.href="index2.php";
}
</script>';
?>