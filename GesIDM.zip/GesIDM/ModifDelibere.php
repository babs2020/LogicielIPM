<?php 
            $nom=filter_input(INPUT_POST,'classe');
            if (isset($nom)) {
                include'connexion.php';
                $id=$_GET['IDDELI'];
                $filiere= $_POST['filiere'];
                $nom_classe=$_POST['classe'];
                 $delibere=$_FILES['delibere']['name'];
                $chemin=$_FILES['delibere']['tmp_name'];
                move_uploaded_file($chemin, "releves/$delibere");
                    if(!empty($filiere) ||  !empty($nom_classe) || !empty($delibere) )
                    {
                                                    /*  incscription de l'utilisateur  */  
                             $q= $db->prepare("UPDATE delibere SET nom_classe=?, filieres=?,supportDeli=?,date_enreg=NOW() WHERE IDDELI=$id");
                              $q->execute([$nom_classe,$filiere,$delibere]); 
                                      if($q){
                                          echo'<script>
                     alert("Modification effectue");
                     document.location.href="ListDelibere.php";
                     </script>';die();
                                  
          
                    }
                                        /*erreur champ vide*/
                    }else{
                         echo'<script>
                               alert("veuillez faire une modification");
                               document.location.href="FormModif.php";
                               </script>';die();
            }
 }
 ?>
