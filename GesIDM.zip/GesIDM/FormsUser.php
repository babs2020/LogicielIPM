<?php 
include'pages/head.php';
?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
<script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php
     include 'pages/sidebar.php';
      ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page">
                    <div class="title-block">
                        <h3 class="title">
    Ajouter un utilisateur
    </h3></div>
                   
                    <section class="section">
                        <div class="row sameheight-container">
                            <div class="col-md-10">
                                <div class="card card-block sameheight-item">
                                    <form method="post" action="EXE/adduser.php" enctype="MULTIPART/FORM-DATA">
                                         <div class="form-group"> <label class="control-label">Nom Utilisateur</label> <input type="text" class="form-control boxed" placeholder="Nom..." name="nom"> </div>
                                         <div class="form-group"> <label class="control-label">Prenom utilisateur</label> <input type="text" class="form-control boxed" placeholder="Prenom..." name="prenom" > </div>
                                        <div class="form-group"> <label class="control-label">Email</label> <input type="email" class="form-control boxed" name="email"> </div>
                                        <div class="form-group"> <label class="control-label">Mot de pass</label>
                                         <input type="password" class="form-control boxed" name="password"> </div>
                                          <div class="form-group"> <label class="control-label">Type Utilisateur</label> <select type="text" class="form-control boxed" name="type"><option>Veuillez selectionner un type</option>
                                          <option>Admin</option>
                                          <option>pedagogue</option>
                                          <option>professeur</option>
                                          <option>Etudiant</option>
                                          <option>administration</option>
                                          <option>comptable</option>
                                          </select> </div>
                                           <div class="form-group"> <label class="control-label">Photo</label> <input type="file" class="form-control boxed" name="photo" id="photo"> </div>
                                           <div class="form-group"> <label class="control-label">adresse</label> <input type="text" class="form-control boxed" name="adresse"> </div>
                                           <div class="form-group"> <label class="control-label">Telephone</label> <input type="text" class="form-control boxed" name="telephone"> </div>
                                        <button type="submit" class="btn btn-oval btn-success">Enregistrer</button> 
                                        <button type="button" class="btn btn-oval btn-Danger" style="margin-left:700px;">Annuler</button> 
                                    </form>
                                </div>
                            </div>
            </div>
            
            </section>
            
            </article>
            <?php include 'pages/footer.php'; ?>