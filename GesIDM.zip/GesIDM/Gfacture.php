<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sideComptable.php'; ?>
    <?php 
     $id= $_GET['id_paiement'];
    include("connexion.php");
    $sql="SELECT * FROM paiement WHERE id_paiement=$id";
    $stmt= $db->prepare($sql);
    $stmt->execute();
    $row=$stmt->fetch();
?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
     <article class="content cards-page">
                    <div class="title-block">
                        <h3 class="title">
Gestion des factures
	</h3>
                        <p> Apres chaque paiement,  l'etudiant doit recevoir sa facture <p>
                    </div>

                    <script>
				    function imprimer(divName) {
				      var printContents = document.getElementById(divName).innerHTML;    
				   var originalContents = document.body.innerHTML;      
				   document.body.innerHTML = printContents;     
				   window.print();     
				   document.body.innerHTML = originalContents;
   }
</script>
<button onClick="imprimer('sectionAimprimer')" type="button" class="btn btn-success btn-lg">Imprimer</button><br><br>
<div id='sectionAimprimer'>
                    <section class="section">
                        <div class="row">
                            <div class="col-xl-10">
                                <div class="card card-primary">
                                    <div class="card-header">
                                        <div class="header-block">
                                            <p class="title"> <img src="img/idm.png" width="100px"><h2 style="color: black;">INSTITUT DAKAROIS DES METIERS </h2></p>
                                        </div>
                                    </div>
                                    <div class="card-block">
                                        <h3><center>Tel: 33 867 01 58</center></h3>
                                        <br>
                                        <h3> <span  style="color: blue;">Recu de Mr/Mme: </span><?php echo $row['prenomEt']." ".$row['nomEt']; ?> </h3>
                                        <br>
                                       	<h3 ><span  style="color: blue;">N°CNI: </span><?php echo $row['cni']; ?> </h3>
                                       	<br>
                                        <h3 ><span  style="color: blue;">Motif du versement:</span> <?php echo $row['motif']; ?> </h3>
                                        <br>
                                        <h3 ><span  style="color: blue;">La Somme:</span> <?php if ($row['motif']=='Inscription') 
                                         echo $row['frais']."FCFA";
                                         else
                                         	echo $row['novembre']."FCFA";
                                     ?> </h3>
                                     <h3><center>Fait a Dakar le <?php echo $row['date_enrg']; ?></center></h3>
                                        
                                    </div>
                                    <div class="card-footer"> <h2>La Comptabilite <center>Directeur</center></h2> 
                                    	<br><br><br><br>
                                       <h3><center>ADRESSE: SIPRES LOT N°1 FRONT DE TERRE PROLONGE-DAKAR</center></h3>
                                    </div>
                                   
                                    
                                </div>
                            </div>
                         </div>
                     </section>
                 </div>
                 </article>
