 <footer class="footer" style="background-color: red;">
                    
                    <div class="footer-block author">
                        <ul>
                        	
                            <li> DEVELOPPER PAR BABACAR ET BINTA EN 2020 </li>
                            <li><center> PROJET DE FIN D'ETUDE</center> </li>
                            <li style="margin-left: : 2040px;"> <?php 
									include("connexion.php");
									$sql="SELECT annee FROM classe where id_classe='46'";
									$stmt= $db->prepare($sql);
									$stmt->execute();
									$row=$stmt->fetch();
									?>
						ANNEE SCOLAIRE:<?php echo $row['annee']; ?></li>
                        </ul>
                    </div>
                </footer>