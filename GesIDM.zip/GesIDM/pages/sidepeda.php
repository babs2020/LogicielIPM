 <?php
session_start() ;
include 'connexion.php'; 
if (isset($_SESSION['pedagogue'])) {
 ?> 
 <aside class="sidebar">
                    <div class="sidebar-container">
                        <div class="sidebar-header">
                            <div class="brand">
                                <img src="img/idm.png">
                        </div>
                        <nav class="menu">
                            <ul class="nav metismenu" id="sidebar-menu">
                                <li class="active">
                                    <a href="index.html"> <i class="fa fa-bars"></i>MENU</a>
                                </li>
                    
                                <li>
                                    <a href=""> <img src="img/images.png" width="30px">  Filieres <i class="fa arrow"></i> </a>
                                    <ul>
                                        <li> <a href="addclGinf.php#Liste des classe Genie informatique&Ajout de classe ">
                                    GENIE INFORMATIQUE
                                </a> </li>
                                        <li> <a href="addclGc.php">
                                  GENIE CIVIL
                                </a> </li>
                                </li>
                                        <li> <a href="addclGElec.php">
                                  GENIE ELECTROMECANIQUE
                                </a> </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href=""><img src="img/delibere.png" width="30px"> Deliberation de note<i class="fa arrow"></i> </a>
                                    <ul>
                                        <li> <a href="ajoutDelibere.php">
                                    Ajouter Deliberaion
                                </a> </li>
                                        <li> <a href="ListDelibere.php">
                                    Lister des deliberations
                                </a> </li>
                                    </ul>
                                </li>
                                <li>
                                    <a href=""><img src="img/note.png" width="30px"> Releve  de note<i class="fa arrow"></i> </a>
                                    <ul>
                                        <li> <a href="ajoutReleve.php">
                                    Ajouter un Relevée
                                </a> </li>
                                        <li> <a href="ListReleve.php">
                                    Lister des relevées de note
                                </a> </li>
                                    </ul>
                                </li>
                                 <li>
                                    <a href=""><img src="img/cour.jpg" width="30px"> Planification des cours<i class="fa arrow"></i> </a>
                                    <ul>
                                        <li> <a href="FormPlanif.php">
                                    Ajouter une planification de cour
                                </a> </li>
                                        <li> <a href="ListPlanif.php">
                                    Lister des planifications de cours
                                </a> </li>
                                    </ul>
                                    <li>
                                    <a href=""><i class="fa fa-calendar"></i>Gestion des emploies du<center>temps<i class="fa arrow"></i></center> </a>
                                    <ul>
                                        <li> <a href="AjoutEmploi.php">
                                    Ajouter un emploie du <center> temps </center>
                                </a> </li>
                                        <li> <a href="ListEmploie.php">
                                    Lister des emploies du <center> temps </center>
                                </a> </li>
                                    </ul>
                                    
                                </li>
                                 <li class="active">
                                    <a href="index.html"> <?php echo "<center>Bienvenue</center><br>"."<i class='fa fa-user'></i>".$_SESSION['email']; ?> </a>
                                    <a class="dropdown-item" href="deconnexion.php"> <i class="fa fa-power-off icon"></i> Deconnexion </a>
                                </li>
                        </nav>
                    </div>
                    <footer class="sidebar-footer">
                        <ul class="nav metismenu" id="customize-menu">
                            <li>
                                <ul>
                                    <li class="customize">
                                        <div class="customize-item">
                                            <div class="row customize-header">
                                                <div class="col-xs-4"> </div>
                                                <div class="col-xs-4"> <label class="title">fixed</label> </div>
                                                <div class="col-xs-4"> <label class="title">static</label> </div>
                                            </div>
                                            <div class="row hidden-md-down">
                                                <div class="col-xs-4"> <label class="title">Sidebar:</label> </div>
                                                <div class="col-xs-4"> <label>
                                            <input class="radio" type="radio" name="sidebarPosition" value="sidebar-fixed" >
                                            <span></span>
                                        </label> </div>
                                                <div class="col-xs-4"> <label>
                                            <input class="radio" type="radio" name="sidebarPosition" value="">
                                            <span></span>
                                        </label> </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-4"> <label class="title">Header:</label> </div>
                                                <div class="col-xs-4"> <label>
                                            <input class="radio" type="radio" name="headerPosition" value="header-fixed">
                                            <span></span>
                                        </label> </div>
                                                <div class="col-xs-4"> <label>
                                            <input class="radio" type="radio" name="headerPosition" value="">
                                            <span></span>
                                        </label> </div>
                                            </div>
                                            <div class="row">
                                                <div class="col-xs-4"> <label class="title">Footer:</label> </div>
                                                <div class="col-xs-4"> <label>
                                            <input class="radio" type="radio" name="footerPosition" value="footer-fixed">
                                            <span></span>
                                        </label> </div>
                                                <div class="col-xs-4"> <label>
                                            <input class="radio" type="radio" name="footerPosition" value="">
                                            <span></span>
                                        </label> </div>
                                            </div>
                                        </div>
                                        <div class="customize-item">
                                            <ul class="customize-colors">
                                                <li> <span class="color-item color-red" data-theme="red"></span> </li>
                                                <li> <span class="color-item color-orange" data-theme="orange"></span> </li>
                                                <li> <span class="color-item color-green" data-theme="green"></span> </li>
                                                <li> <span class="color-item color-seagreen" data-theme="seagreen"></span> </li>
                                                <li> <span class="color-item color-blue active" data-theme=""></span> </li>
                                                <li> <span class="color-item color-purple" data-theme="purple"></span> </li>
                                            </ul>
                                        </div>
                                    </li>
                                </ul>
                                <a href=""> <i class="fa fa-cog"></i> Customize </a>
                            </li>
                        </ul>
                    </footer>
                </aside>
                <?php } else{
                    echo '<script type="text/javascript">
                            document.location.href="index.php"
                        </script>';
                } ?>