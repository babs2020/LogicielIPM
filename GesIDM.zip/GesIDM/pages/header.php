    
        <header class="header" style="background-color: orange;">
                    <div class="header-block header-block-collapse hidden-lg-up"> <button class="collapse-btn" id="sidebar-collapse-btn">
                <i class="fa fa-bars"></i>
            </button> </div>
                    
                     <center><marquee> <img src="img/idm.png" width="50px"><h2 style="color: black;"> BIENVENUE A L'INSTITUT DES METIERS </h2></marquee></center>
                    
            </header>