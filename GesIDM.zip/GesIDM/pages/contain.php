
<article class="content dashboard-page">
                    <section class="section">
                        <div class="row sameheight-container">
                            <div class="col col-xs-12 col-sm-12 col-md-6 col-xl-5 stats-col">
                                <div class="card sameheight-item stats" data-exclude="xs">
                                    <div class="card-block">
                                        <div class="title-block">
                                            <h4 class="title">
            				Statistique de l'etablissement
            			</h4>
                                        </div>
                                        <div class="row row-sm stats-container">
                                            <div class="col-xs-12 col-sm-6 stat-col">
                                                <div class="stat-icon"> <img src="img/etudiant.jpg" width="50px"> </div>
                                                <div class="stat">
                                                    <div class="value"> 900 </div>
                                                    <div class="name"> Etudiant </div>
                                                </div> <progress class="progress stat-progress" value="75" max="100">
            					<div class="progress">
            						<span class="progress-bar" style="width: 75%;"></span>
            					</div>
            				</progress> </div>
                                                          <?php  include("connexion.php");
                                                          $req0 =$db->prepare("SELECT SUM(filieres) FROM classe GROUP BY filieres");
                                                                $req0->execute();
                                                                $nb0= $req0->rowCount() 
                                                                  ?>
                                            <div class="col-xs-12 col-sm-6 stat-col">
                                                <div class="stat-icon"><img src="img/images.png" width="50px"></i> </div>
                                                <div class="stat">
                                                    <div class="value"><?php echo $nb0 ;?> </div>
                                                    <div class="name">Filieres </div>
                                                </div> <progress class="progress stat-progress" value="25" max="100">
            					<div class="progress">
            						<span class="progress-bar" style="width: 25%;"></span>
            					</div>
            				</progress> </div>
                                            <div class="col-xs-12 col-sm-6  stat-col">
                                                <div class="stat-icon"> <i class="fa fa-windows"></i> </div>
                                                <div class="stat">
                                                    <div class="value">4</div>
                                                    <div class="name"> Service </div>
                                                </div> <progress class="progress stat-progress" value="60" max="100">
            					<div class="progress">
            						<span class="progress-bar" style="width: 60%;"></span>
            					</div>
            				</progress> </div>
                                                        <?php  include("connexion.php");
                                                          $req =$db->prepare("SELECT SUM(nom) FROM utilisateur GROUP BY id");
                                                                $req->execute();
                                                                $nb= $req->rowCount() 
                                                                  ?>
                                            <div class="col-xs-12 col-sm-6  stat-col">
                                                <div class="stat-icon"> <i class="fa fa-user"></i> </div>
                                                <div class="stat">
                                                    <div class="value">
                                                       <?php echo $nb; ?></div>
                                                    <div class="name">Utilisateurs </div>
                                                </div> <progress class="progress stat-progress" value="34" max="100">
            					<div class="progress">
            						<span class="progress-bar" style="width: 34%;"></span>
            					</div>
            				</progress> </div>
                                            <div class="col-xs-12 col-sm-6  stat-col">
                                                <div class="stat-icon"> <i class="fa fa-home"></i> </div>
                                                <div class="stat">
                                                    <div class="value">5 </div>
                                                    <div class="name"> Sales </div>
                                                </div> <progress class="progress stat-progress" value="49" max="100">
            					<div class="progress">
            						<span class="progress-bar" style="width: 49%;"></span>
            					</div>
            				</progress> </div>
                                                     <?php  include("connexion.php");
                                                          $req1 =$db->prepare("SELECT SUM(nom) FROM utilisateur where type='professeur'  ");
                                                                $req1->execute();
                                                                $nb1= $req1->rowCount() 
                                                                  ?>
                                            <div class="col-xs-12 col-sm-6 stat-col">
                                                <div class="stat-icon"> <i class="fa fa-users"></i> </div>
                                                <div class="stat">
                                                    <div class="value"><?php echo $nb1; ?></div>
                                                    <div class="name"> Proffeseurs </div>
                                                </div> <progress class="progress stat-progress" value="15" max="100">
            					<div class="progress">
            						<span class="progress-bar" style="width: 15%;"></span>
            					</div>
            				</progress> </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col col-xs-12 col-sm-12 col-md-6 col-xl-7 history-col">
                                <div class="card sameheight-item" data-exclude="xs">
                                    <div class="card-header card-header-sm bordered">
                                        <div class="header-block">
                                            <h3 class="title">Statistique des classes sous forme de diagramme</h3> </div>
                                    </div>
                                    <div class="card-block">
                                        <div class="tab-content">
                                          <img src="img/graphe.jpg" width="700px">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                    <section class="section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                            Derniers Etudiants inscrit
                        </h3> </div>
                         <?php 
                            include("connexion.php");
                            $sql="SELECT * FROM etudiant";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                        ?>
                                        <section class="example">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                     <thead>
                                                        <tr>
                                                            <th>Photo</th>
                                                            <th>Matricule</th>
                                                            <th>Nom</th>
                                                            <th>Prenom</th>
                                                            <th>Date Naissance</th>
                                                            <th>Lieu de Naissance</th>
                                                            <th>Pays</th>
                                                            <th>Adresse</th>
                                                            <th>Email</th>
                                                            <th>Telephone</th>
                                                            <th>Filiere</th>
                                                            <th>Classe</th>
                                                            <th>Sexe</th>
                                                            <th>CNI</th>
                                                            <th>Telephone Parent</th>
                                                            <th>Telephone Tuteur</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                        <tr>
                                                            <td><img src="img/<?php echo $row['photo']; ?>" width="60" height="60"/></td>
                                                            <td><?php echo $row['matricule'];?></td>
                                                            <td><?php echo $row['nomEt'];?></td>
                                                            <td><?php echo $row['prenomEt'];?></td>
                                                            <td><?php echo $row['dateNaiss'];?></td>
                                                            <td><?php echo $row['lieuNaiss']; ?></td>
                                                            <td><?php echo $row['pays']; ?></td>
                                                            <td><?php echo $row['adresse']; ?></td>
                                                            <td><?php echo $row['email']; ?></td>
                                                            <td><?php echo $row['telephone']; ?></td>
                                                            <td><?php echo $row['filieres'];?></td>
                                                            <td><?php echo $row['classe']; ?></td>
                                                            <td><?php echo $row['sexe'];?></td>
                                                            <td><?php echo $row['CNI'];?></td>
                                                            <td><?php echo $row['TelPrt'];?></td>
                                                            <td><?php echo $row['TelTut'];?></td>
                                                         </tr>
                                                          <?php  
                                                               $i++;
                                                            }?>
                                            
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </article>
                <script src="js/vendor.js"></script>
              <script src="js/app.js"></script>