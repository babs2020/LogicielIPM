<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content buttons-page" style="background-color:#592341;">
	 <div class="title-block">
	 	<h3 class="title">
						Ajouter DEliberation
					</h3> </div>
					 <?php 
                            include("connexion.php");
                            $sql="SELECT nom_classe FROM classe GROUP BY nom_classe";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                            //$row=$stmt->fetch();
                        ?>
                            <form role="form" action="EXE/addDelibere.php" method="POST" enctype="MULTIPART/FORM-DATA">
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Classe</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="classe">
                                	<option>Selectionner une classe</option>
                                	<?php while($row=$stmt->fetch()){ ?><option><?php echo $row['nom_classe']; }?></option>
                                </select> </fieldset>
                                <fieldset class="form-group">
                                <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Filiere</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="filiere">
                                	<option>Selectionner une filiere</option>
                                						 <?php 
				                            include("connexion.php");
				                            $sql="SELECT filieres FROM classe GROUP BY filieres ";
				                            $fl= $db->prepare($sql);
				                            $fl->execute();
				                            //$row=$stmt->fetch();
				                        ?>
                                	<?php while($row=$fl->fetch()){ ?><option><?php echo $row['filieres']; }?></option>
                                </select> </fieldset>
                                <fieldset class="form-group">
                                <label class="control-label" for="formGroupExampleInput4">Fichier Deliberation</label> <input type="file" class="form-control" name="delibere" id="cours"> </fieldset>
                                       <button type="submit" class="btn btn-oval btn-success">Enregistrer</button>
                                       <button type="reset" class="btn btn-oval btn-danger" style="margin-left: 700px;">Annuler</button> 
                            </form>
           </div>
       </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>
<?php
include'connexion.php';
    $classe= $_POST['classe'];
    $filiere= $_POST['filiere'];
    $fichier=$_FILES['delibere']['name'];
    $chemin=$_FILES['delibere']['tmp_name'];
     move_uploaded_file($chemin, "fichier_cour/$fichier");
          if(isset($_FILES['delibere']['name']))
                {
                    $req= $db->prepare('SELECT IDDELI from delibere where supportDeli=?');
                    $req->execute([$fichier]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("il est deja utilisee");
                   document.location.href="cours.php";
                   </script>';die();
                            }else{
           /*  incscription de l'utilisateur  */  
                $q= $db->prepare("INSERT INTO delibere SET nom_classe=?,filieres=?,supportDeli=?,date_enrg=NOW()");
                $q->execute([$classe,$filiere, $fichier]);
                echo'<script>
                   alert("Deliberation effectuee");
                   document.location.href="index2.php";
                   </script>';die();
                            }
                      }  
                      
?>