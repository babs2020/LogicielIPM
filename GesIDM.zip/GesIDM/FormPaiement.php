<?php 
include'pages/head.php';
?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
<script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sideComptable.php'; ?>
     <?php 
    include("connexion.php");
    $id= $_GET['id_paiement'];
    $sql="SELECT * FROM paiement WHERE id_paiement=$id";
    $stmt= $db->prepare($sql);
    $stmt->execute();
    $row=$stmt->fetch();
?>

    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page">
                    <div class="title-block">
                        <h3 class="title">
	Modifier  Le paiement <?php echo $row['nomEt']." ".$row['prenomEt'] ; ?>
	</h3></div>
                   
                    <section class="section">
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card card-block sameheight-item">
                                    <form method="post" action="modifPaiement.php?id_paiement=<?php echo $row['id_paiement']; ?>" enctype="MULTIPART/FORM-DATA">
                                         <div class="form-group"> <label class="control-label">Matricule</label> <input type="text" class="form-control boxed" placeholder="Nom..." name="matricule" value="<?php echo $row['matricule']; ?>"> </div>
                                         <div class="form-group"> <label class="control-label">N°CNI</label> <input type="text" class="form-control boxed" placeholder="Nom..." name="cni" value="<?php echo $row['cni']; ?>"> </div>
                                        <div class="form-group"> <label class="control-label">Nom Etudiant</label> <input type="text" class="form-control boxed" placeholder="Nom..." name="nomEt" value="<?php echo $row['nomEt']; ?>"> </div>
                                         <div class="form-group"> <label class="control-label">Prenom Eudiant</label> <input type="text" class="form-control boxed" placeholder="Prenom..." name="prenomEt" value="<?php echo $row['prenomEt']; ?>" > </div>
                                         <div class="form-group"> <label class="control-label">Date de Naissance</label> <input type="date" class="form-control boxed" placeholder="Prenom..." name="dateNaiss" value="<?php echo $row['dateNaiss']; ?>"> </div>
                                         <div class="form-group"> <label class="control-label">Lieu de Naissance</label> <input type="text" class="form-control boxed" placeholder="Prenom..." name="lieuNais" value="<?php echo $row['lieuNaiss']; ?>" > </div>
                                          <div class="form-group"> <label class="control-label">Cout de la formation</label> <input type="number" class="form-control boxed" name="cout" value="<?php echo $row['cout']; ?>"> </div>
                                          <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Motif de paiement</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="motif" >
                                    <option><?php echo $row['motif'];?></option>                                                                 
                                    <option>Inscription</option>
                                     <option>Mensualite(Novembre)</option>
                                      <option>Mensualite(Decembre)</option>
                                       <option>Mensualite(Janvier)</option>
                                     <option>Mensualite(Fevrier)</option>
                                      <option>Mensualite(Mars)</option>
                                       <option>Mensualite(Avril)</option>
                                        <option>Mensualite(Mai)</option>
                                         <option>Mensualite(Juin)</option>
                                          <option>Mensualite(Juillet)</option>
                                           <option>Mensualite(Aout)</option></select>
                                         <div class="form-group"> <label class="control-label">Frais</label> <input type="frais" class="form-control boxed" placeholder="Nom..." name="frais" value="<?php echo $row['frais']; ?>"> </div>
                                    
                                             <div class="form-group"> <label class="control-label">Mensualite Novembre</label> <input type="number" class="form-control boxed" name="Novembre" value="<?php echo $row['novembre']; ?>"> </div>
                                              <div class="form-group"> <label class="control-label">Mensualite Decembre</label> <input type="number" class="form-control boxed" name="decembre" value="<?php echo $row['decembre']; ?>"> </div>
                                               <div class="form-group"> <label class="control-label">Mensualite Janvier</label> <input type="number" class="form-control boxed" name="janvier" value="<?php echo $row['janvier']; ?>"> </div>
                                                <div class="form-group"> <label class="control-label">Mensualite Fevrier</label> <input type="number" class="form-control boxed" name="fevrier" value="<?php echo $row['fevrier']; ?>"> </div>
                                                <div class="form-group"> <label class="control-label">Mensualite  Mars</label> <input type="number" class="form-control boxed" name="mars" value="<?php echo $row['mars']; ?>"> </div>
                                                 <div class="form-group"> <label class="control-label">Mensualite Avril</label> <input type="number" class="form-control boxed" name="avril" value="<?php echo $row['avril']; ?>"> </div>
                                                  <div class="form-group"> <label class="control-label">Mensualite Mai</label> <input type="number" class="form-control boxed" name="mai" value="<?php echo $row['mai']; ?>"> </div>
                                                   <div class="form-group"> <label class="control-label">Mensualite juin</label> <input type="number" class="form-control boxed" name="juin" value="<?php echo $row['juin']; ?>"> </div>
                                                    <div class="form-group"> <label class="control-label">Mensualite juillet</label> <input type="number" class="form-control boxed" name="juillet" value="<?php echo $row['juillet']; ?>"> </div>
                                                    <div class="form-group"> <label class="control-label">Mensualite Aout</label> <input type="number" class="form-control boxed" name="aout" value="<?php echo $row['aout']; ?>"> </div>
                                        <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Filiere</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="filiere">
                                    <option><?php echo $row['filiere']; ?></option>
                                       <?php 
                                            include("connexion.php");
                                            $sql="SELECT filieres FROM classe GROUP BY filieres ";
                                            $fl= $db->prepare($sql);
                                            $fl->execute();
                                            //$row=$stmt->fetch();
                                        ?>
                                    <?php while($row=$fl->fetch()){ ?><option><?php echo $row['filieres']; }?></option>
                                </select> </fieldset>
                                                 <?php 
                                                        include("connexion.php");
                                                        $id= $_GET['id_paiement'];
                                                        $sql="SELECT classe FROM paiement WHERE id_paiement=$id";
                                                        $stmt= $db->prepare($sql);
                                                        $stmt->execute();
                                                        $cl=$stmt->fetch();
                                                    ?>


                                 <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Classe</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="classe">
                                    <option value="<?php echo $cl['classe']; ?>"><?php echo $cl['classe']; ?></option>
                                     <?php 
                            include("connexion.php");
                            $sql="SELECT nom_classe FROM classe GROUP BY nom_classe";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                            //$row=$stmt->fetch();
                        ?>
                                    <?php while($row1=$stmt->fetch()){ ?><option><?php echo $row1['nom_classe']; }?></option>
                                </select> </fieldset>
                                    
                                        <button type="submit" class="btn btn-oval btn-success">Modifier</button> 
                                        <button type="reset" class="btn btn-oval btn-Danger" style="margin-left:700px;">Annuler</button>  
                                    </form>
                                </div>
                            </div>
            </div>
            </section>
            
            </article>
        </div>
    </div>
    <?php include 'pages/footer.php'; ?>