<?php 
include'pages/head.php';
?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
<script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php
     include 'pages/sideComptable.php';
      ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page" style="background-color: #393;">
                    <div class="title-block">
                        <h3 class="title">
    PAGE Scolarite DES ETUDIANTS
    </h3></div>
                   
                    <section class="section" style="background-color: #432139;">
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card card-block sameheight-item">
                                    <form method="post" action="EXE/addComptable.php" enctype="MULTIPART/FORM-DATA">
                                     <div class="form-group"> <label class="control-label">Matricule</label> <input type="text" class="form-control boxed" placeholder="CNI..." name="matricule" > </div>
                                      <div class="form-group"> <label class="control-label">N°CNI</label> <input type="text" class="form-control boxed" placeholder="CNI..." name="cni" > </div>
                                     <div class="form-group"> <label class="control-label">Nom Etudiant</label> <input type="text" class="form-control boxed" placeholder="Nom..." name="nomEt" > </div>
                                         <div class="form-group"> <label class="control-label">Prenom Eudiant</label> <input type="text" class="form-control boxed" placeholder="Prenom..." name="prenomEt" > </div>
                                         <div class="form-group"> <label class="control-label">Date de Naissance</label> <input type="date" class="form-control boxed" placeholder="Prenom..." name="dateNaiss" > </div>
                                         <div class="form-group"> <label class="control-label">Lieu de Naissance</label> <input type="text" class="form-control boxed" placeholder="Prenom..." name="lieuNais" > </div>
                                       
                                                                           <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Filiere</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="filiere">
                                    <option>Selectionner une filiere</option>
                                                         <?php 
                                            include("connexion.php");
                                            $sql="SELECT filieres FROM classe GROUP BY filieres ";
                                            $fl= $db->prepare($sql);
                                            $fl->execute();
                                            //$row=$stmt->fetch();
                                        ?>
                                    <?php while($row=$fl->fetch()){ ?><option><?php echo $row['filieres']; }?></option>
                                </select> </fieldset>
                                 <?php 
                            include("connexion.php");
                            $sql="SELECT nom_classe FROM classe GROUP BY nom_classe";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                            //$row=$stmt->fetch();
                        ?>
                                 <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Classe</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="classe">
                                    <option>Selectionner une classe</option>
                                    <?php while($row=$stmt->fetch()){ ?><option><?php echo $row['nom_classe']; }?></option>
                                </select> </fieldset>
                                            <div class="form-group"> <label class="control-label">cout de la formation</label> <input type="number" class="form-control boxed" name="cout"> </div>
                                      <fieldset class="form-group"> <label class="control-label" for="formGroupExampleInput3">Motif de paiement</label> <select type="text" class="form-control" id="formGroupExampleInput3" name="moitif">
                                    <option>......Selectionner un motif.....</option>                                                                 
                                    <option>Inscription</option>
                                     <option>Mensualite(Novembre)</option>
                                      <option>Mensualite(Decembre)</option>
                                       <option>Mensualite(Janvier)</option>
                                     <option>Mensualite(Fevrier)</option>
                                      <option>Mensualite(Mars)</option>
                                       <option>Mensualite(Avril)</option>
                                        <option>Mensualite(Mai)</option>
                                         <option>Mensualite(Juin)</option>
                                          <option>Mensualite(Juillet)</option>
                                           <option>Mensualite(Aout)</option></select>
                                             <div class="form-group"> <label class="control-label">Frais Inscription</label> <input type="number" class="form-control boxed" name="frais"> </div>
                                             <div class="form-group"> <label class="control-label">Mensualite Novembre</label> <input type="number" class="form-control boxed" name="Novembre" value="0"> </div>
                                              <div class="form-group"> <label class="control-label">Mensualite Decembre</label> <input type="number" class="form-control boxed" name="decembre" value="0"> </div>
                                               <div class="form-group"> <label class="control-label">Mensualite Janvier</label> <input type="number" class="form-control boxed" name="janvier" value="0"> </div>
                                                <div class="form-group"> <label class="control-label">Mensualite Fevrier</label> <input type="number" class="form-control boxed" name="fevrier" value="0"> </div>
                                                <div class="form-group"> <label class="control-label">Mensualite  Mars</label> <input type="number" class="form-control boxed" name="mars" value="0"> </div>
                                                 <div class="form-group"> <label class="control-label">Mensualite Avril</label> <input type="number" class="form-control boxed" name="avril" value="0"> </div>
                                                  <div class="form-group"> <label class="control-label">Mensualite Mai</label> <input type="number" class="form-control boxed" name="mai" value="0"> </div>
                                                   <div class="form-group"> <label class="control-label">Mensualite juin</label> <input type="number" class="form-control boxed" name="juin" value="0"> </div>
                                                    <div class="form-group"> <label class="control-label">Mensualite juillet</label> <input type="number" class="form-control boxed" name="juillet" value="0"> </div>
                                                    <div class="form-group"> <label class="control-label">Mensualite Aout</label> <input type="number" class="form-control boxed" name="aout" value="0"> </div>
                                        <button type="submit" class="btn btn-oval btn-success">Enregistrer</button> 
                                        <button type="button" class="btn btn-oval btn-Danger" style="margin-left:700px;">Annuler</button> 
                                    </form>
                                </div>
                            </div>
            </div>
            
            </section>
            
            </article>