<?php
session_start ();
$loginOK=false;
include('connexion.php');
$login = trim($_POST['email']);
$password = trim($_POST['password']); 
 
if (empty($_POST['email']) || empty($_POST['password'])) { 
echo'<body onLoad="alert(\'Vous devez verifier le formulaire authentification...\')">';
echo '<meta http-equiv="refresh" content="0;URL=index.php">';
}else{
$query = "SELECT id,nom,prenom,email,password  FROM utilisateur where email='$login' and password='$password'";
$results =$db->query($query) or die ("echec de l'exÃ©cution de la requÃªte<br>." );
   if($results->rowCount() > 0){
   $data = $results->fetch();
   $loginOK=true;

   }else{echo'<body onLoad="alert(\'Ce utilisateur est non reconu dans le systeme...\')">';
   echo '<meta http-equiv="refresh" content="0;URL=index.php">';
   }
}
if($loginOK){
	$sql=$db->query("SELECT  id,nom,prenom,email,password,type  FROM utilisateur where email='$login' and password='$password'");
	$sql->execute();
	if($sql->rowCount()>0){
	   if($data=$sql->fetch()){
		if($data['type']=="Admin") {
			$_SESSION['email'] =$login;
			$_SESSION['Admin'] = $data['type'];
			echo '<meta http-equiv="refresh" content="0;URL=identification.php">';
		}else if($data['type']=="pedagogue"){
		     $_SESSION['email'] =$login;
		     $_SESSION['pedagogue'] = $data['type'];
		     header("Location: index1.php");
			//echo '<meta http-equiv="refresh" content="0;URL=index1.php"';
		}else if($data['type']=="professeur"){
             $_SESSION['email'] =$login;
		     $_SESSION['professeur'] = $data['type'];
		     header("Location: index2.php"); 
     }else if($data['type']=="Administration"){
		     $_SESSION['email'] =$login;
		     $_SESSION['administration'] = $data['type'];
		     header("Location: indexAdmin.php"); 
	}else if($data['type']=="comptable"){
		     $_SESSION['email'] =$login;
		     $_SESSION['comptable'] = $data['type'];
		     header("Location: paiement.php"); 
	}
			//echo '<meta http-equiv="refresh" content="0;URL=index2.php">';
  }  			
  }  
}else{
echo'Une erreur est survenue lors de ouverture de la session essayer de nouveau';
}
?>
