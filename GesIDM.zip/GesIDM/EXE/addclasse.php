<?php
include'../connexion.php';
	$classe= $_POST['classe'];
	$filiere= $_POST['filiere'];
  $Date = date("d-m-Y");  
  $Year = date("Y");
  $annee=date("Y")-0001;
  $anneSc=$annee."---".$Year;

          if(isset($_POST['nom_classe']) || isset($_POST['filiere']))
                {

                    $req= $db->prepare('SELECT nom_classe from classe where filieres=? and nom_classe=?');
                    $req->execute([$filiere,$classe]);
                    $cl=$req->fetch();
                    if($cl){
                    echo'<script>
                   alert("Cet Classe est deja enregistre");
                   document.location.href="../Formclasse.php";
                   </script>';die();

                            }else{
           /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("INSERT INTO classe SET nom_classe=?,filieres=?,annee=?");
                                $q->execute([$classe,$filiere,$anneSc]);
                                echo'<script>
                   alert("Classe enregistre");
                   document.location.href="../addclGinf.php";
                   </script>';die();
                           }
                      }  
?>