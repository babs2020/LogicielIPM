<?php
include'../connexion.php';
  $matricule= $_POST['matricule'];
  $cni=$_POST['cni'];
	$nom= $_POST['nomEt'];
	$prenom= $_POST['prenomEt'];
    $dateNaiss= $_POST['dateNaiss'];
    $lieuNaiss= $_POST['lieuNais'];
    $filiere=$_POST['filiere'];
    $classe= $_POST['classe'];
    $cout= $_POST['cout'];
    $motif=$_POST['moitif'];
    $frais=$_POST['frais'];
    $novembre= $_POST['Novembre'];
    $decembre= $_POST['decembre'];
    $janvier= $_POST['janvier'];
    $fevrier= $_POST['fevrier'];
    $mars= $_POST['mars'];
    $avril= $_POST['avril'];
    $mai= $_POST['mai'];
    $juin= $_POST['juin'];
    $juillet= $_POST['juillet'];
    $aout= $_POST['aout'];
    $totaux=$frais+$novembre+$decembre+$janvier+$fevrier+$mars+$avril+$mai+$juin+$juillet+$aout;
    $creance=$cout-$totaux;
          if(isset($matricule))
                {

                    $req= $db->prepare('SELECT id_paiement from paiement where matricule=?');
                    $req->execute([$matricule]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("Cet matricule  est deja utilisé ");
                   document.location.href="../paiement.php";
                   </script>';die();

                            }else{
           /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("INSERT INTO paiement SET matricule=?, cni=?, nomEt=?,prenomEt=?,dateNaiss=?,lieuNaiss=?,filiere=?,classe=?,cout=?,frais=?,novembre=?,decembre=?,janvier=?,fevrier=?,mars=?,avril=?,mai=?,juin=?,juillet=?,aout=?,totaux=?,creance=?,date_enrg=NOW()");
                                $q->execute([$matricule,$cni,$nom,$prenom, $dateNaiss, $lieuNaiss, $filiere, $classe, $cout, $motif, $frais, $novembre, $decembre,$janvier, $fevrier, $mars, $avril, $mai, $juin, $juillet, $aout, $totaux, $creance]);
                                echo'<script>
                   alert("Inscription effectuee");
                   document.location.href="../ListUtil.php";
                   </script>';die();
                            }
                      }  
?>