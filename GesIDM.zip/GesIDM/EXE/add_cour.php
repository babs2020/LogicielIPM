
<?php
include'../connexion.php';
	$nom_cours= $_POST['nom_cours'];
	$classe= $_POST['classe'];
	$filiere= $_POST['filiere'];
	$description= $_POST['desc'];
    $IDCOURS=$nom_cours."-".$classe;
    $fichier=$_FILES['cours']['name'];
    $chemin=$_FILES['cours']['tmp_name'];
     move_uploaded_file($chemin, "../fichier_cour/$fichier");
          if(isset($_POST['nom_cours']))
                {
                    $req= $db->prepare('SELECT idcours from cours where nom_cour=?');
                    $req->execute([$nom_cours]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("il est deja utilisee");
                   document.location.href="../cours.php";
                   </script>';die();
                            }else{
           /*  incscription de l'utilisateur  */  
                $q= $db->prepare("INSERT INTO cours SET IDCOURS=?,nom_cour=?,nom_classe=?,filieres=?,f_cours=?,description=?,date_enrg=NOW()");
                $q->execute([$IDCOURS,$nom_cours,$classe,$filiere, $fichier, $description]);
                echo'<script>
                   alert("cours enregistree");
                   document.location.href="../index2.php";
                   </script>';die();
                            }
                      }  
?>