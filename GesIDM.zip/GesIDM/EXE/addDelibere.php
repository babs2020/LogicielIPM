<?php
include'../connexion.php';
    $classe= $_POST['classe'];
    $filiere= $_POST['filiere'];
    $fichier=$_FILES['delibere']['name'];
    $chemin=$_FILES['delibere']['tmp_name'];
     move_uploaded_file($chemin, "fichier_cour/$fichier");
          if(isset($_FILES['delibere']['name']))
                {
                    $req= $db->prepare('SELECT IDDELI from delibere where supportDeli=?');
                    $req->execute([$fichier]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("il est deja utilisee");
                   document.location.href="../ajoutDelibere.php";
                   </script>';die();
                            }else{
           /*  incscription de l'utilisateur  */  
                $q= $db->prepare("INSERT INTO delibere SET nom_classe=?,filieres=?,supportDeli=?,date_enreg=NOW()");
                $q->execute([$classe,$filiere, $fichier]);
                echo'<script>
                   alert("Deliberation effectuee");
                   document.location.href="../ListDelibere.php";
                   </script>';die();
                            }
                      }  
?>