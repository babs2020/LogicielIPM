<?php
include'../connexion.php';
    $classe= $_POST['classe'];
    $filiere= $_POST['filiere'];
    $fichier=$_FILES['emploie']['name'];
    $chemin=$_FILES['emploie']['tmp_name'];
     move_uploaded_file($chemin, "../Emploie/$fichier");
          if(isset($_FILES['emploie']['name']))
                {
                    $req= $db->prepare('SELECT id_emploie from emploie where fiche_emploie=?');
                    $req->execute([$fichier]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("il est deja enregistre");
                   document.location.href="AjoutEmploi.php";
                   </script>';die();
                            }else{
           /*  incscription de l'utilisateur  */  
                $q= $db->prepare("INSERT INTO emploie SET nom_classe=?,filieres=?,fiche_emploie=?,date_enreg=NOW()");
                $q->execute([$classe,$filiere, $fichier]);
                echo'<script>
                   alert("Enregistrement Effectue");
                   document.location.href="../ListEmploie.php";
                   </script>';die();
                            }
                      }  
                      
?>