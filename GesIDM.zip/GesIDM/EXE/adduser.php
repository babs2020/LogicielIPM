<?php
include'../connexion.php';
	$nom= $_POST['nom'];
	$prenom= $_POST['prenom'];
    $email= $_POST['email'];
    $type= $_POST['type'];
   // $password= $_POST['password'];
    $photo=$_FILES['photo']['name'];
    $chemin=$_FILES['photo']['tmp_name'];
     move_uploaded_file($chemin, "../img/$photo");
     $password=$nom.$prenom;
     $adresse= $_POST['adresse'];
     $telephone= $_POST['telephone'];
          if(filter_var($_POST['email'],FILTER_VALIDATE_EMAIL))
                {

                    $req= $db->prepare('SELECT id from utilisateur where email=?');
                    $req->execute([$email]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("Cet email est deja utilisé dans un autre utilisateur");
                   document.location.href="../FormsUser.php";
                   </script>';die();

                            }else{
           /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("INSERT INTO utilisateur SET nom=?,prenom=?,email=?,type=?,password=?,photo=?,adresse=?,telephone=?");
                                $q->execute([$nom,$prenom,$email, $type, $password, $photo, $adresse, $telephone]);
                                echo'<script>
                   alert("Inscription effectuee");
                   document.location.href="../ListUtil.php";
                   </script>';die();
                            }
                      }  
?>