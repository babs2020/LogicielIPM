<?php
include'../connexion.php';
    $classe= $_POST['classe'];
    $filiere= $_POST['filiere'];
    $fichier=$_FILES['note']['name'];
    $chemin=$_FILES['note']['tmp_name'];
     move_uploaded_file($chemin, "../Note/$fichier");
          if(isset($_FILES['note']['name']))
                {
                    $req= $db->prepare('SELECT id_note from Note where fiche_note=?');
                    $req->execute([$fichier]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("il est deja utilisee");
                   document.location.href="../Form_Note.php";
                   </script>';die();
                            }else{
           /*  incscription de l'utilisateur  */  
                $q= $db->prepare("INSERT INTO Note SET nom_classe=?,filieres=?,fiche_note=?,date_enrg=NOW()");
                $q->execute([$classe,$filiere, $fichier]);
                echo'<script>
                   alert("insertion  effectuee");
                   document.location.href="../ListNote.php";
                   </script>';die();
                            }
                      }  
                      
?>