<?php
include'../connexion.php';
    $classe= $_POST['classe'];
    $filiere= $_POST['filiere'];
    $fichier=$_FILES['planif']['name'];
    $chemin=$_FILES['planif']['tmp_name'];
     move_uploaded_file($chemin, "fichier_cour/$fichier");
          if(isset($_FILES['planif']['name']))
                {
                    $req= $db->prepare('SELECT id_planif from planification where fichier_planif=?');
                    $req->execute([$fichier]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("il est deja utilisee");
                   document.location.href="../FormPlanif.php";
                   </script>';die();
                            }else{
           /*  incscription de l'utilisateur  */  
                $q= $db->prepare("INSERT INTO planification SET nom_classe=?,filieres=?,fichier_planif=?,date_enreg=NOW()");
                $q->execute([$classe,$filiere, $fichier]);
                echo'<script>
                   alert("Enregistrement effectuee");
                   document.location.href="../ListPlanif.php";
                   </script>';die();
                            }
                      }  
?>