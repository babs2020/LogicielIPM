<?php
include'../connexion.php';
	
          if(isset($matricule))
                {

                    $req= $db->prepare('SELECT id_et from etudiant where matricule=?');
                    $req->execute([$matricule]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("Cet email est deja utilisé dans un autre utilisateur");
                   document.location.href="../AjoutEt.php";
                   </script>';die();

                            }else{
           /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("INSERT INTO etudiant SET matricule=?,nomEt=?,prenomEt=?,dateNaiss=?,lieuNaiss=?,pays=?,adresse=?,email=?,telephone=?,filieres=?,classe=?,sexe=?,CNI=?,TelPrt=?,TelTut=?,photo=?");
                                $q->execute([$matricule,$nomEt,$prenomEt, $dateNaiss, $lieuNaiss, $pays, $adresse, $email,$telephone,$filiere,$classe, $sexe, $CNI, $TelPrt, $TelTut, $photo]);
                                echo'<script>
                   alert("Inscription effectuee");
                   document.location.href="../ListEt.php";
                   </script>';die();
                            }
                      }  
?>