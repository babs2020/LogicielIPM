<?php 
            $nom=filter_input(INPUT_POST,'classe');
            if (isset($nom)) {
                include'connexion.php';
                $id=$_GET['id_note'];
                $filiere= $_POST['filiere'];
                $nom_classe=$_POST['classe'];
                $Note=$_FILES['note']['name'];
                $chemin=$_FILES['note']['tmp_name'];
                move_uploaded_file($chemin, "Note/$Note");
                    if(!empty($filiere) ||  !empty($nom_classe) || !empty($Note) )
                    {
                                                    /*  incscription de l'utilisateur  */  
                             $q= $db->prepare("UPDATE Note SET nom_classe=?, filieres=?,fiche_Note=?,date_enrg=NOW() WHERE id_note=$id");
                              $q->execute([$nom_classe,$filiere,$Note]); 
                                      if($q){
                                          echo'<script>
                     alert("Modification effectue");
                     document.location.href="ListNote.php";
                     </script>';die();
                                  
          
                    }
                                        /*erreur champ vide*/
                    }else{
                         echo'<script>
                               alert("veuillez faire une modification");
                               document.location.href="FormModif.php";
                               </script>';die();
            }
 }
 ?>
