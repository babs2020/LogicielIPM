
<?php
include'connexion.php';
    $classe= $_POST['classe'];
    $filiere= $_POST['filiere'];
    $fichier=$_FILES['releve']['name'];
    $chemin=$_FILES['releve']['tmp_name'];
     move_uploaded_file($chemin, "releves/$fichier");
          if(isset($_FILES['releve']['name']))
                {
                    $req= $db->prepare('SELECT id_releve from releve where releve=?');
                    $req->execute([$fichier]);
                    $user=$req->fetch();
                    if($user){
                    echo'<script>
                   alert("Ce relevé existe déja);
                   document.location.href="ajoutReleve.php";
                   </script>';die();
                            }else{
           /*  incscription de l'utilisateur  */  
                $q= $db->prepare("INSERT INTO releve SET nom_classe=?,filieres=?,releve=?,date_enreg=NOW()");
                $q->execute([$classe,$filiere, $fichier]);
                echo'<script>
                   confirm("insertion éfféctué");
                   document.location.href="ListReleve.php";
                   </script>';die();
                            }
                      }  
?>