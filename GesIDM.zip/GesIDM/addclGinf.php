<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content buttons-page" style="background-color: blue;">
	 <div class="title-block">
    <section class="section">
                <div class="row sameheight-container">
                    <div class="col-md-12">
                        <div class="card card-block sameheight-item">
                            <div class="title-block">
                                <h3 class="title">
						Formulaire d'ajout classe
					</h3> </div>
                            <form action="EXE/addclasse.php" method="POST">
                                <div class="form-group"> <input class="form-control form-control-lg" type="text" placeholder="Nom de la classe" name="classe"> </div>
                                <div class="form-group"> <select class="form-control form-control-lg" name="filiere">
							<option>Selectionner une filiere</option>
							<option>Genie informatique</option>
							<option>Genie civil</option>
							<option>Genie Electromecanique</option>
						</select> </div>
                        <button type="submit" class="btn btn-oval btn-success">Enregistrer</button>
                            </form>
                        </div>
                    </div>
                            </form>
                        </div>
                    </div>
                    <?php 
                            include("connexion.php");
                            $sql="SELECT * FROM classe where filieres='Genie informatique'";
                            $stmt= $db->prepare($sql);
                            $stmt->execute();
                        ?>
                    <section class="section">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">

                            Liste des classe de  Genie informatique
                        </h3> </div>
                                        <section class="example">
                                            <table class="table table-inverse">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Nom de la classe</th>
                                                        <th>Filiere</th>
                                                        <th>Action et vue(cour, matiere, Emploie du temps)</ </th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                     <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                    <tr>
                                                        <th scope="row"><?php echo $i++; ?></th>
                                                        <td><?php echo $row['nom_classe']; ?></td>
                                                        <td><?php echo $row['filieres']; ?></td>
                                                        <td><center><a href="Form_MC.php?id_classe=<?php echo $row['id_classe']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-edit" data-icon="modifier"></em></div></a>
                                                                <a href="supp_classe.php?id_classe=<?php echo $row['id_classe']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"  aria-expanded="true" ></em></div></a>
                                                                <a href="Vue.php?id_classe=<?php echo $row['id_classe']; ?>"><div class="col-md-3 col-sm-4"><img src="img/vue.png" width="30px"></div></a></center> </td>
                                                    </tr>
                                                   <?php } ?>
                                                </tbody>
                                            </table>
                                        </section>
                </div>

            </section>
           
           </div>
       </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>