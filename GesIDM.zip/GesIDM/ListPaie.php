<?php include 'pages/head.php'; ?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
        <script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sideComptable.php'; ?>
    <?php 
    include("connexion.php");
    $sql="SELECT * FROM paiement";
    $stmt= $db->prepare($sql);
    $stmt->execute();
?>
    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content static-tables-page" style="background-color: #783452;">
                    <div class="title-block">
                         <a href="paiement.php"> <button type="button" class="btn btn-success btn-lg">Nouveau paiement</button></a>
     <section class="section" style="background-color: #40912798;">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="card">
                                    <div class="card-block">
                                        <div class="card-title-block">
                                            <h3 class="title">
                           <center> Liste de Paiement</center>
                        </h3> </div>
                                        <section class="example">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                        	<th>Numero</th>
                                                            <th>Matricule</th>
                                                            <th>N°CNI</th>
                                                            <th>Nom</th>
                                                            <th>Prenom</th>
                                                            <th>Date Naissance</th>
                                                            <th>Lieu de Naissance</th>
                                                            <th>Filiere</th>
                                                            <th>Classe</th>
                                                            <th>Cout de la Formation</th>
                                                            <th>Motif du paiement</th>
                                                            <th>Frais Inscription</th>
                                                            <th>Mensualite Novembre</th>
                                                            <th>Mensualite Decembre</th>
                                                            <th>Mensualite Janvier</th>
                                                            <th>Mensualite Fevrier</th>
                                                            <th>Mensualite Mars</th>
                                                            <th>Mensualite Avril</th>
                                                            <th>Mensualite Mai</th>
                                                            <th>Mensualite Juin</th>
                                                            <th>Mensualite Juillet</th>
                                                            <th>Mensualite Aout</th>
                                                            <th>Total</th>
                                                            <th>Creance</th>
                                                            <th>Date de paiement</th>
                                                            <th>Action</th>

                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php  
                                                        $i=1;
                                                        while($row=$stmt->fetch()){?>
                                                        <tr>
                                                            <td><?php echo $i; ?></td>
                                                            <td><?php echo $row['matricule'];?></td>
                                                            <td><?php echo $row['cni']; ?></td>
                                                            <td><?php echo $row['nomEt'];?></td>
                                                            <td><?php echo $row['prenomEt'];?></td>
                                                            <td><?php echo $row['dateNaiss'];?></td>
                                                            <td><?php echo $row['lieuNaiss']; ?></td>
                                                            <td><?php echo $row['filiere']; ?></td>
                                                            <td><?php echo $row['classe']; ?></td>
                                                            <td><?php echo $row['cout']." "."FCFA"; ?></td>
                                                            <td><?php echo $row['motif']; ?></td>
                                                            <td><?php echo $row['frais']." "."FCFA"; ?></td>
                                                            <td><?php echo $row['novembre']." "."FCFA";?></td>
                                                            <td><?php echo $row['decembre']." "."FCFA"; ?></td>
                                                            <td><?php echo $row['janvier']." "."FCFA";?></td>
                                                            <td><?php echo $row['fevrier']." "."FCFA";?></td>
                                                            <td><?php echo $row['mars']." "."FCFA";?></td>
                                                            <td><?php echo $row['avril']." "."FCFA";?></td>
                                                            <td><?php echo $row['mai']." "."FCFA";?></td>
                                                            <td><?php echo $row['juin']." "."FCFA";?></td>
                                                            <td><?php echo $row['juillet']." "."FCFA";?></td>
                                                            <td><?php echo $row['aout']." "."FCFA";?></td>
                                                            <td><?php echo $row['totaux']." "."FCFA";?></td>
                                                            <td><?php echo $row['creance']." "."FCFA";?></td>
                                                            <td><?php echo $row['date_enrg']; ?></td>
                                                            <td style="width: 100px;"><a href="FormPaiement.php?id_paiement=<?php echo $row['id_paiement']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-edit"></em></div></a>
                                                            	<a href="suppEt.php?id_paiement=<?php echo $row['id_paiement']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa fa-trash-o"></em></div></a>
                                                              <a href="Gfacture.php?id_paiement=<?php echo $row['id_paiement']; ?>"><div class="col-md-3 col-sm-4"> <em class="fa  fa-ticket" ></em></div></a>
                                                            </td>
                                                        </tr>
                                                          <?php  
                                                               $i++;
                                                            }?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </section>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
                </article>
</div>
</div>
<?php include 'pages/footer.php'; ?>