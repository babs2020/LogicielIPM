<?php 
include'pages/head.php';
?>
<div class="main-wrapper">
<div class="app" id="app">
<?php include 'pages/header.php'; ?>
<script src="js/vendor.js"></script>
        <script src="js/app.js"></script>
    <?php include 'pages/sidepeda.php'; ?>
     <?php 
    include("connexion.php");
    $id= $_GET['id_classe'];
    $sql="SELECT * FROM classe WHERE id_classe=$id";
    $stmt= $db->prepare($sql);
    $stmt->execute();
    $row=$stmt->fetch();
?>

    <div class="sidebar-overlay" id="sidebar-overlay"></div>
    <article class="content forms-page">
                    <div class="title-block">
                        <h3 class="title">
    Modifier la classe<?php echo $row['nom_classe'] ; ?>
    </h3></div>
                   
                    <section class="section">
                        <div class="row sameheight-container">
                            <div class="col-md-12">
                                <div class="card card-block sameheight-item">
                                    <form method="post" action="" enctype="MULTIPART/FORM-DATA">
                                         <div class="form-group"> <label class="control-label">Nom de la classe</label> <input type="text" class="form-control boxed" placeholder="Nom..." name="nom_classe" value="<?php echo $row['nom_classe'] ?>"> </div>
                                         <div class="form-group"> <label class="control-label">Filiere</label> <select class="form-control form-control-lg" name="filiere">
                            <option><?php echo $row['filieres'] ?></option>
                        </select> </div> </div>
                                        
                                       <button type="submit" class="btn btn-oval btn-success">Enregistrer</button>
                                       <button type="submit" class="btn btn-oval btn-danger" style="margin-left: 700px;">Annuler</button> 
                                    </form>
                                </div>
                            </div>
            </div>
            </section>
            
            </article>
        </div>
    </div>
    <?php 
$nom=filter_input(INPUT_POST,'nom_classe');
if (isset($nom)) {
    include'connexion.php';
    $id= $_GET['id_classe'];
    $nom_classe= $_POST['nom_classe'];
    $filiers= $_POST['filiere'];
     $Date = date("d-m-Y");  
  $Year = date("Y");
  $annee=date("Y")-0001;
  $anneSc=$anneeYear."---".$Year;

        if(!empty($nom_classe) || !empty($filieres))
        {
                                        /*  incscription de l'utilisateur  */  
                                $q= $db->prepare("UPDATE classe SET nom_classe=?,filieres=?, annee=? WHERE id_classe=$id");
                                $q->execute([$nom_classe,$filiers,$anneSc]); 
                                    if($q){
                                        echo'<script>
                   alert("Modification effectue");
                   document.location.href="addclGinf.php";
                   </script>';die();
                                header("location:addclGinf.php");
        
                  }
                            /*erreur champ vide*/
        }else{
             echo'<script>
                   alert("veuillez faire une modification");
                   document.location.href="FormModif.php";
                   </script>';die();
}
}
 ?>
