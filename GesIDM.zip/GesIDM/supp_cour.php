<?php
	include("connexion.php");
	
	$id = filter_input(INPUT_GET, "id_cour", FILTER_SANITIZE_NUMBER_INT) ;
	
	$typemsg="";
	$message=""; 
	
	$resquet = "DELETE FROM  cours WHERE id_cour = $id " ;
			if($db->exec($resquet)){
					echo'<script>
                   alert("Le cour est  supprime");
                   document.location.href="index2.php";
                   </script>';die();			
				}else{
					$message="deja supprime
					<br>";
					$style="warning";
					$titremsg="Erreur!";
			}

?>